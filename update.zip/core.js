// Разбор подписок и сборка конфига sing-box
const b64 = s => { s = s.trim().replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; return Buffer.from(s, 'base64').toString('utf8'); };
const isB64 = s => /^[A-Za-z0-9+/=_\-\s]+$/.test(s.trim()) && s.trim().length > 16;

function tlsFrom(q, host) {
  const sec = q.get('security');
  if (sec !== 'tls' && sec !== 'reality' && q.get('tls') !== 'tls') return undefined;
  const t = { enabled: true, server_name: q.get('sni') || q.get('peer') || host, insecure: q.get('allowInsecure') === '1' || q.get('insecure') === '1' };
  const fp = q.get('fp'); if (fp) t.utls = { enabled: true, fingerprint: fp };
  const alpn = q.get('alpn'); if (alpn) t.alpn = decodeURIComponent(alpn).split(',');
  if (sec === 'reality' && t.utls) t.utls.fingerprint = 'chrome';
  if (sec === 'reality') { t.reality = { enabled: true, public_key: q.get('pbk'), short_id: q.get('sid') || '' }; if (!t.utls) t.utls = { enabled: true, fingerprint: 'chrome' }; }
  return t;
}
function transportFrom(type, q) {
  const path = q.get('path') ? decodeURIComponent(q.get('path')) : undefined; const host = q.get('host');
  if (type === 'ws') return { type: 'ws', path: path || '/', headers: host ? { Host: host } : undefined };
  if (type === 'grpc') return { type: 'grpc', service_name: q.get('serviceName') || q.get('path') || '' };
  if (type === 'httpupgrade') return { type: 'httpupgrade', path: path || '/', host };
  if (type === 'http' || type === 'h2') return { type: 'http', path, host: host ? [host] : undefined };
  return undefined;
}

function parseUri(line) {
  line = line.trim(); if (!line) return null;
  try {
    if (line.startsWith('vmess://')) {
      const j = JSON.parse(b64(line.slice(8)));
      const o = { type: 'vmess', server: j.add, server_port: +j.port, uuid: j.id, alter_id: +j.aid || 0, security: j.scy || 'auto' };
      const q = new URLSearchParams({ path: j.path || '', host: j.host || '', sni: j.sni || '', security: j.tls === 'tls' ? 'tls' : '', alpn: j.alpn || '', fp: j.fp || '', serviceName: j.path || '' });
      if (!j.alpn) q.delete('alpn'); if (!j.fp) q.delete('fp');
      o.tls = tlsFrom(q, j.sni || j.host || j.add); o.transport = transportFrom(j.net, q);
      return { name: j.ps || j.add, ob: o };
    }
    if (line.startsWith('ss://')) {
      let rest = line.slice(5), name = '';
      const h = rest.indexOf('#'); if (h >= 0) { name = decodeURIComponent(rest.slice(h + 1)); rest = rest.slice(0, h); }
      rest = rest.split('?')[0];
      let userinfo, hostport;
      if (rest.includes('@')) { [userinfo, hostport] = rest.split('@'); userinfo = userinfo.includes(':') ? decodeURIComponent(userinfo) : b64(userinfo); }
      else { const d = b64(rest); const i = d.lastIndexOf('@'); userinfo = d.slice(0, i); hostport = d.slice(i + 1); }
      const ci = userinfo.indexOf(':'); const pi = hostport.lastIndexOf(':');
      return { name: name || hostport, ob: { type: 'shadowsocks', server: hostport.slice(0, pi).replace(/[\[\]]/g, ''), server_port: +hostport.slice(pi + 1), method: userinfo.slice(0, ci), password: userinfo.slice(ci + 1) } };
    }
    const u = new URL(line); const q = u.searchParams; const name = decodeURIComponent(u.hash.slice(1)) || u.hostname;
    const server = u.hostname.replace(/[\[\]]/g, ''), port = +u.port || 443, user = decodeURIComponent(u.username);
    switch (u.protocol) {
      case 'vless:': {
        const type = q.get('type') || 'tcp';
        if (type === 'xhttp' || type === 'splithttp' || type === 'kcp' || (q.get('encryption') || 'none') !== 'none') return { name, type: 'vless', xr: xrayVless(u, q) };
        const o = { type: 'vless', server, server_port: port, uuid: user, tls: tlsFrom(q, server), transport: transportFrom(type, q) };
        if (q.get('flow')) o.flow = q.get('flow'); else if (type === 'tcp') o.packet_encoding = 'xudp'; // 12.11: vision вернул — 11.11 обрывы были из-за бага сервера (flow пустой у d77)
        return { name, ob: o };
      }
      case 'trojan:': {
        if (!q.get('security')) q.set('security', 'tls');
        return { name, ob: { type: 'trojan', server, server_port: port, password: user, tls: tlsFrom(q, server), transport: transportFrom(q.get('type') || 'tcp', q) } };
      }
      case 'hysteria2:': case 'hy2:': {
        const o = { type: 'hysteria2', server, server_port: port, password: user + (u.password ? ':' + decodeURIComponent(u.password) : ''), tls: { enabled: true, server_name: q.get('sni') || server, insecure: q.get('insecure') === '1', alpn: ['h3'] } };
        if (q.get('obfs')) o.obfs = { type: q.get('obfs'), password: q.get('obfs-password') || '' };
        return { name, ob: o };
      }
      case 'tuic:': return { name, ob: { type: 'tuic', server, server_port: port, uuid: user, password: decodeURIComponent(u.password), congestion_control: q.get('congestion_control') || 'bbr', tls: { enabled: true, server_name: q.get('sni') || server, insecure: q.get('allow_insecure') === '1', alpn: (q.get('alpn') || 'h3').split(',') } } };
    }
  } catch (e) { return null; }
  return null;
}

// Сервер, который умеет только ядро Xray (xhttp и т.п.)
function xrayVless(u, q) {
  const host = u.hostname.replace(/[\[\]]/g, ''), type = q.get('type') === 'splithttp' ? 'xhttp' : (q.get('type') || 'tcp'), sec = q.get('security') || 'none';
  const user = { id: decodeURIComponent(u.username), encryption: q.get('encryption') || 'none' }; if (q.get('flow')) user.flow = q.get('flow');
  const ss = { network: type, security: sec };
  const sni = q.get('sni') || q.get('host') || host, fp = q.get('fp') || 'chrome';
  if (sec === 'tls') { ss.tlsSettings = { serverName: sni, fingerprint: fp, allowInsecure: q.get('allowInsecure') === '1' }; if (q.get('alpn')) ss.tlsSettings.alpn = q.get('alpn').split(','); }
  if (sec === 'reality') ss.realitySettings = { serverName: sni, fingerprint: fp, publicKey: q.get('pbk'), shortId: q.get('sid') || '', spiderX: q.get('spx') || '' };
  if (type === 'xhttp') { const x = { path: q.get('path') || '/', mode: q.get('mode') || 'auto' }; if (q.get('host')) x.host = q.get('host'); if (q.get('extra')) { try { x.extra = JSON.parse(q.get('extra')); } catch { } } ss.xhttpSettings = x; }
  if (type === 'kcp') ss.kcpSettings = { header: { type: q.get('headerType') || 'none' }, seed: q.get('seed') || undefined };
  if (type === 'ws') ss.wsSettings = { path: q.get('path') || '/', host: q.get('host') || undefined };
  if (type === 'grpc') ss.grpcSettings = { serviceName: q.get('serviceName') || '' };
  return { protocol: 'vless', server: host, settings: { vnext: [{ address: host, port: +u.port || 443, users: [user] }] }, streamSettings: ss };
}
const XPORT = 21000;
const usable = (nodes, hasXray) => nodes.filter(n => n.ob || (n.xr && hasXray));
function buildXray(nodes) {
  const xs = nodes.filter(n => !n.ob && n.xr); if (!xs.length) return null;
  return clean({
    log: { loglevel: 'warning' },
    inbounds: xs.map((n, i) => ({ tag: 'in-' + i, listen: '127.0.0.1', port: XPORT + i, protocol: 'socks', settings: { udp: true } })),
    outbounds: xs.map((n, i) => { const { server, ...o } = n.xr; return { ...o, tag: 'out-' + i }; }),
    routing: { rules: xs.map((n, i) => ({ type: 'field', inboundTag: ['in-' + i], outboundTag: 'out-' + i })) },
  });
}

function parseSubscription(text) {
  text = text.trim();
  if (text.startsWith('{')) { // sing-box JSON
    try { const j = JSON.parse(text); return (j.outbounds || []).filter(o => !['direct', 'block', 'dns', 'selector', 'urltest'].includes(o.type)).map(o => { const n = o.tag; delete o.tag; return { name: n, ob: o }; }); } catch { }
  }
  if (!text.includes('://') && isB64(text)) text = b64(text);
  return text.split(/\r?\n/).map(parseUri).filter(Boolean);
}

function parseUserInfo(h) {
  if (!h) return null; const r = {};
  h.split(';').forEach(p => { const [k, v] = p.trim().split('='); if (k) r[k] = +v; });
  return r;
}

// Пресеты приложений: процессы + домены
const APP_PRESETS = {
  steam: { name: 'Steam', process: ['steam.exe', 'steamwebhelper.exe', 'steamservice.exe', 'gameoverlayui.exe'], domains: ['steampowered.com', 'steamcommunity.com', 'steamstatic.com', 'steamcontent.com', 'steamserver.net', 'steamusercontent.com', 'steam-chat.com', 'valvesoftware.com', 'steamgames.com'] },
  telegram: { name: 'Telegram', process: ['telegram.exe', 'ayugram.exe', 'kotatogram.exe'], domains: ['telegram.org', 't.me', 'telegram.me', 'telegra.ph', 'tdesktop.com', 'telesco.pe', 'cdn-telegram.org'], ipcidr: ['91.108.4.0/22', '91.108.8.0/22', '91.108.12.0/22', '91.108.16.0/22', '91.108.20.0/22', '91.108.56.0/22', '149.154.160.0/20', '95.161.64.0/20', '185.76.151.0/24'] },
  discord: { name: 'Discord', process: ['discord.exe', 'update.exe'], domains: ['discord.com', 'discord.gg', 'discordapp.com', 'discordapp.net', 'discord.media', 'discordcdn.com'] },
  youtube: { name: 'YouTube', process: [], domains: ['youtube.com', 'youtu.be', 'googlevideo.com', 'ytimg.com', 'ggpht.com', 'youtubei.googleapis.com'] },
  spotify: { name: 'Spotify', process: ['spotify.exe'], domains: ['spotify.com', 'scdn.co', 'spotifycdn.com'] },
  chatgpt: { name: 'ChatGPT', process: ['chatgpt.exe'], domains: ['openai.com', 'chatgpt.com', 'oaiusercontent.com', 'oaistatic.com'] },
  claude: { name: 'Claude', process: ['claude.exe'], domains: ['claude.ai', 'anthropic.com', 'claude.com'] },
  instagram: { name: 'Instagram', process: [], domains: ['instagram.com', 'cdninstagram.com', 'fbcdn.net', 'facebook.com'] },
  epic: { name: 'Epic Games', process: ['epicgameslauncher.exe', 'epicwebhelper.exe'], domains: ['epicgames.com', 'unrealengine.com', 'epicgames.dev'] },
  faceit: { name: 'FACEIT', process: ['faceit.exe', 'faceitclient.exe', 'faceitservice.exe'], domains: ['faceit.com', 'faceit-cdn.net'] },
};

const RU_DOMAINS = ['ru', 'xn--p1ai', 'su', 'yandex.com', 'yandex.net', 'ya.ru', 'vk.com', 'vk.me', 'userapi.com', 'mail.ru', 'ok.ru', 'avito.ru', 'ozon.ru', 'wildberries.ru', 'gosuslugi.ru', 'sberbank.ru', 'tinkoff.ru', 'tbank.ru', 'yastatic.net', 'vkuser.net', 'mycdn.me', 'kinopoisk.ru', 'rutube.ru', 'dzen.ru'];

function ruleFor(item) {
  const r = {};
  if (item.kind === 'site') { r.domain_suffix = [item.value.replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/^www\./, '').toLowerCase()]; }
  else {
    const p = item.preset && APP_PRESETS[item.preset];
    const procs = [...(p ? p.process : []), ...(item.process || [])].map(s => s.toLowerCase());
    if (procs.length) r.process_name = [...new Set(procs)];
    if (item.folder) r.process_path_regex = ['(?i)^' + item.folder.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\\\'];
    const doms = [...(p ? p.domains : []), ...(item.domains || [])]; if (doms.length) r.domain_suffix = doms;
    if (p && p.ipcidr) r.ip_cidr = p.ipcidr;
  }
  return r;
}

// Сборка правил: каждое поле — отдельное правило (OR), так процессы и домены работают независимо
function expandRule(base, outbound) {
  return Object.entries(base).map(([k, v]) => ({ [k]: v, outbound }));
}

function buildConfig(state, opts = {}) {
  const nodes = usable(state.nodes, opts.hasXray); // [{tag, ob | xr}]
  const s = state.settings; let xi = 0; const xhosts = [];
  const outbounds = nodes.map(n => n.ob ? ({ ...n.ob, tag: n.tag }) : (xhosts.push(n.xr.server), { type: 'socks', tag: n.tag, server: '127.0.0.1', server_port: XPORT + xi++, version: '5' }));
  const tags = nodes.map(n => n.tag);
  outbounds.unshift({ type: 'selector', tag: 'proxy', outbounds: tags.length ? tags : ['direct'], default: state.selected && tags.includes(state.selected) ? state.selected : tags[0], interrupt_exist_connections: true });
  outbounds.push({ type: 'direct', tag: 'direct' });

  const cfg = {
    log: { level: s.logLevel || 'info', timestamp: true },
    dns: {
      servers: [
        { type: 'https', tag: 'remote', server: '1.1.1.1', detour: 'proxy' },
        { type: 'udp', tag: 'local', server: '77.88.8.8' },
      ],
      rules: [], final: 'remote', strategy: 'ipv4_only',
    },
    inbounds: [], outbounds,
    route: { rules: [], final: 'proxy', auto_detect_interface: true, default_domain_resolver: 'local' },
    experimental: { clash_api: { external_controller: '127.0.0.1:' + (opts.apiPort || 9095), secret: '' }, cache_file: opts.test ? undefined : { enabled: true, path: opts.cachePath } },
  };
  if (opts.test) { cfg.dns = undefined; cfg.route = { final: 'proxy', default_domain_resolver: undefined }; cfg.log.level = 'warn'; return clean(cfg); }

  cfg.inbounds.push({ type: 'tun', tag: 'tun-in', interface_name: 'StormTun', address: ['172.19.0.1/30'], mtu: 9000, auto_route: true, strict_route: true, stack: s.stack || 'mixed' });
  cfg.inbounds.push({ type: 'mixed', tag: 'mixed-in', listen: '127.0.0.1', listen_port: 2080 });

  const R = cfg.route.rules;
  R.push({ action: 'sniff' });
  R.push({ protocol: 'dns', action: 'hijack-dns' });
  R.push({ ip_is_private: true, outbound: 'direct' });
  R.push({ process_name: ['sing-box.exe', 'xray.exe'], outbound: 'direct' });
  const xd = xhosts.filter(h => /[a-z]/i.test(h)); if (xd.length) cfg.dns.rules.push({ domain: xd, server: 'local' });

  const directDomains = [];
  if (opts.zapretDomains) { // Discord и YouTube: при включённом запрете — напрямую (через запрет), иначе — через VPN
    outbounds.splice(outbounds.length - 1, 0, { type: 'selector', tag: 'zapret-route', outbounds: ['direct', 'proxy'], default: state.zapret && state.zapret.on ? 'direct' : 'proxy', interrupt_exist_connections: true });
    R.push({ process_name: ['discord.exe', 'update.exe', 'discordptb.exe', 'discordcanary.exe'], outbound: 'zapret-route' });
    R.push({ domain_suffix: opts.zapretDomains, outbound: 'zapret-route' });
  }
  if (state.mode !== 'global') {
    for (const item of state.rules.filter(r => r.enabled !== false)) {
      const base = ruleFor(item); const out = 'rule-' + item.id;
      outbounds.splice(outbounds.length - 1, 0, { type: 'selector', tag: out, outbounds: ['proxy', 'direct'], default: item.action === 'direct' ? 'direct' : 'proxy', interrupt_exist_connections: true });
      R.push(...expandRule(base, out));
      if (item.action === 'direct' && base.domain_suffix) directDomains.push(...base.domain_suffix);
    }
    if (s.ruDirect) { R.push({ domain_suffix: RU_DOMAINS, outbound: 'direct' }); directDomains.push(...RU_DOMAINS); }
  }
  if (directDomains.length) cfg.dns.rules.push({ domain_suffix: directDomains, server: 'local' });
  return clean(cfg);
}

function clean(o) { return JSON.parse(JSON.stringify(o)); }

module.exports = { parseSubscription, parseUserInfo, buildConfig, buildXray, usable, APP_PRESETS };
