﻿# РЈСЃС‚Р°РЅРѕРІРєР° Storm VPN: Р·Р°РґР°С‡Р° РїР»Р°РЅРёСЂРѕРІС‰РёРєР° СЃ РїСЂР°РІР°РјРё Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂР° (РЅСѓР¶РЅР° РґР»СЏ TUN) + СЏСЂР»С‹РєРё
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$electron = Join-Path $root 'node_modules\electron\dist\electron.exe'
$user = "$env:USERDOMAIN\$env:USERNAME"
$action = New-ScheduledTaskAction -Execute $electron -Argument "`"$root`"" -WorkingDirectory $root
$principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit 0 -MultipleInstances IgnoreNew -Priority 4
Register-ScheduledTask -TaskName 'StormVPN' -Action $action -Principal $principal -Settings $settings -Force | Out-Null

$sh = New-Object -ComObject WScript.Shell
foreach ($p in @(([Environment]::GetFolderPath('Desktop') + '\Storm 2.0.lnk'), "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Storm 2.0.lnk")) {
  $l = $sh.CreateShortcut($p)
  $l.TargetPath = "$env:WINDIR\System32\wscript.exe"
  $l.Arguments = '"' + (Join-Path $root 'launch.vbs') + '"'
  $l.WorkingDirectory = $root
  $l.IconLocation = (Join-Path $root 'assets\icons\night.ico')
  $l.Description = 'Storm 2.0'
  $l.Save()
}
New-Item -ItemType Directory -Force (Join-Path $root 'data') | Out-Null
'OK' | Out-File (Join-Path $root 'data\installed.txt')

