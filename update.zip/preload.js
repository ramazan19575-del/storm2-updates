const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('vpn', {
  call: (ch, a) => ipcRenderer.invoke(ch, a),
  win: a => ipcRenderer.send('win', a),
  on: (ch, f) => ipcRenderer.on(ch, (_, d) => f(d)),
});
