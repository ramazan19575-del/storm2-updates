const { app, BrowserWindow, ipcMain, Tray, Menu, nativeImage, dialog, shell, clipboard, desktopCapturer, screen } = require('electron');
const jsQR = require('jsqr');
const path = require('path'), fs = require('fs'), http = require('http'), { spawn, execFile } = require('child_process');
const core = require('./core');

const ROOT = __dirname, DATA = path.join(ROOT, 'data'), SB = path.join(ROOT, 'core', 'sing-box.exe');
fs.mkdirSync(DATA, { recursive: true });
const STATE_FILE = path.join(DATA, 'state.json');
const API = 9095, TEST_API = 9096, TASK = 'StormVPN', XR = path.join(ROOT, 'core', 'xray.exe');
const hasXray = () => fs.existsSync(XR);
const crypto = require('crypto'), os = require('os');

if (!app.requestSingleInstanceLock()) { app.quit(); process.exit(0); }
try { require('os').setPriority(0); } catch { } // задача планировщика даёт пониженный приоритет — возвращаем обычный

const defaults = {
  subs: [], selected: null, mode: 'rules',
  rules: [
    { id: 'r1', kind: 'app', preset: 'telegram', name: 'Telegram', action: 'proxy' },
    { id: 'r2', kind: 'app', preset: 'steam', name: 'Steam', action: 'direct' },
    { id: 'r3', kind: 'app', preset: 'discord', name: 'Discord', action: 'proxy' },
  ],
  settings: { theme: 'dark', pinConnect: true, style: 'compact', icon: 'night', closeToTray: true, autostart: false, autoConnect: false, ruDirect: true, stack: 'mixed', logLevel: 'info', pingUrl: 'http://cp.cloudflare.com/generate_204', pingMode: 'real' },
  stats: { totalUp: 0, totalDown: 0, sessions: 0 },
};
let state = load();
if (/gstatic/.test(state.settings.pingUrl)) state.settings.pingUrl = 'http://cp.cloudflare.com/generate_204'; // 11.11: без TLS — пинг ближе к реальному
if (!state.hwid) state.hwid = crypto.randomUUID().replace(/-/g, '');
const ICONS = ['night', 'snow', 'ocean', 'wblack', 'wwhite', 'wdark', 'wgray', 'wmint', 'wsunset', 'neon', 'sunset', 'graphite'];
if (!ICONS.includes(state.settings.icon)) state.settings.icon = 'night';
state.settings.style = 'compact'; state.settings.pinConnect = true; // один стиль — компактный, кнопка всегда внизу
const SIZES = { classic: [340, 540], compact: [340, 540] };
function load() { try { const s = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); return { ...defaults, ...s, settings: { ...defaults.settings, ...s.settings }, stats: { ...defaults.stats, ...s.stats } }; } catch { return JSON.parse(JSON.stringify(defaults)); } }
let saveT; function save() { clearTimeout(saveT); saveT = setTimeout(() => fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 1)), 200); }

let win, tray, proc = null, status = 'off', logs = [], quitting = false, traffic = { up: 0, down: 0 }, session = { up: 0, down: 0, start: 0 };
const send = (ch, d) => win && !win.isDestroyed() && win.webContents.send(ch, d);
function log(line) { line = String(line).replace(/\x1b\[[0-9;]*m/g, '').trim(); if (!line) return; logs.push(line); if (logs.length > 800) logs.shift(); send('log', line); }

const allNodes = () => state.subs.flatMap(s => s.nodes.map(n => ({ ...n, sub: s.id })));

// ---------- подписки ----------
async function fetchSub(sub) {
  const raw = !/^https?:\/\//i.test(sub.url);
  const r = raw ? { headers: { get: () => null } } : await fetch(sub.url, { headers: { 'User-Agent': 'v2rayN/7.12 Storm/2.0 (Windows)', 'x-hwid': state.hwid, 'x-device-os': 'Windows', 'x-device-model': 'Storm 2.0 ' + os.hostname().slice(0, 20), 'x-ver-os': os.release() }, signal: AbortSignal.timeout(20000) });
  if (!raw && !r.ok) throw new Error('Сервер подписки ответил ' + r.status);
  const text = raw ? sub.url : await r.text();
  const parsed = core.parseSubscription(text);
  const ok = parsed.filter(p => p.ob || p.xr);
  if (!ok.length) throw new Error('В подписке нет поддерживаемых серверов');
  const ui = core.parseUserInfo(r.headers.get('subscription-userinfo'));
  let title = r.headers.get('profile-title'); if (title && title.startsWith('base64:')) title = Buffer.from(title.slice(7), 'base64').toString();
  const old = Object.fromEntries((sub.nodes || []).map(n => [n.name, n]));
  sub.nodes = ok.map((p, i) => ({ tag: `${sub.id}-${i}`, name: p.name, ob: p.ob, xr: p.xr, type: p.ob ? p.ob.type : p.type, ping: old[p.name] ? old[p.name].ping : null }));
  sub.skipped = parsed.length - ok.length;
  sub.info = ui; sub.updated = Date.now(); if (!sub.name && title) sub.name = title;
  if (!sub.name) sub.name = raw ? (ok.length === 1 ? ok[0].name : 'Мои серверы') : new URL(sub.url).hostname;
}
ipcMain.handle('sub:add', async (_, { url, name }) => {
  if (state.subs.some(s => s.url === url.trim())) throw new Error('Эта подписка уже добавлена');
  const sub = { id: 's' + Date.now().toString(36), url: url.trim(), name: name || '', nodes: [] };
  await fetchSub(sub); state.subs.push(sub); if (!state.selected) state.selected = sub.nodes[0].tag; save(); return pub();
});
ipcMain.handle('sub:refresh', async (_, id) => {
  const list = id ? state.subs.filter(s => s.id === id) : state.subs; const errs = [];
  const sig = () => JSON.stringify(allNodes().map(n => [n.tag, n.ob, n.xr])); const before = sig();
  for (const s of list) { try { await fetchSub(s); } catch (e) { errs.push(s.name + ': ' + e.message); } }
  if (!allNodes().some(n => n.tag === state.selected)) state.selected = allNodes()[0]?.tag || null;
  save(); if (status === 'on' && sig() !== before) await restart(); // перезапуск только если сами серверы изменились
  return { ...pub(), errors: errs };
});
ipcMain.handle('sub:remove', async (_, id) => { state.subs = state.subs.filter(s => s.id !== id); if (!allNodes().some(n => n.tag === state.selected)) state.selected = allNodes()[0]?.tag || null; save(); return pub(); });
ipcMain.handle('sub:rename', (_, { id, name }) => { const s = state.subs.find(x => x.id === id); if (s) s.name = name; save(); return pub(); });

// ---------- ядро ----------
function writeConfig(file, cfg) { fs.writeFileSync(file, JSON.stringify(cfg, null, 1)); }
function api(method, p, body, port = API, timeout = 8000) {
  return new Promise((res, rej) => {
    const rq = http.request({ host: '127.0.0.1', port, path: p, method, timeout, headers: { 'Content-Type': 'application/json' } }, r => { let d = ''; r.on('data', c => d += c); r.on('end', () => { try { res(d ? JSON.parse(d) : {}); } catch { res({}); } }); });
    rq.on('error', rej); rq.on('timeout', () => { rq.destroy(); rej(new Error('timeout')); }); if (body) rq.write(JSON.stringify(body)); rq.end();
  });
}
function setStatus(s) { status = s; send('status', s); updateTray(); }

async function connect() {
  if (proc) return;
  const nodes = allNodes(); if (!core.usable(nodes, hasXray()).length) throw new Error('Сначала добавьте подписку');
  const other = otherVpn(); if (other) throw new Error('Сейчас включён другой VPN: ' + other + '. Выключите его и нажмите ещё раз');
  const cur = nodes.find(n => n.tag === state.selected); if (cur && !cur.ob && !hasXray()) throw new Error('Этому серверу нужно ядро Xray — выберите другой');
  const cfg = core.buildConfig({ ...state, nodes }, { apiPort: API, cachePath: path.join(DATA, 'cache.db'), hasXray: hasXray(), zapretDomains: zDomains(), steamGames: (steamSig = steamKey(), steamGames()) });
  startXray(nodes);
  const file = path.join(DATA, 'config.json'); writeConfig(file, cfg);
  setStatus('connecting'); log('— Запуск ядра, режим: ' + (state.mode === 'global' ? 'ВСЁ через VPN' : 'по правилам'));
  proc = spawn(SB, ['run', '-c', file, '-D', DATA], { windowsHide: true, cwd: path.dirname(SB) });
  try { os.setPriority(proc.pid, -7); } catch { }
  proc.stdout.on('data', d => String(d).split('\n').forEach(log));
  proc.stderr.on('data', d => String(d).split('\n').forEach(log));
  proc.on('exit', code => { log('— Ядро остановлено (код ' + code + ')'); proc = null; stopXray(); stopTraffic(); setStatus('off'); });
  for (let i = 0; i < 40; i++) { await new Promise(r => setTimeout(r, 250)); if (!proc) throw new Error('Ядро не запустилось — смотрите логи'); try { await api('GET', '/version'); break; } catch { } }
  if (!proc) throw new Error('Ядро не запустилось');
  session = { up: 0, down: 0, start: Date.now() }; state.stats.sessions++; save();
  setStatus('on'); startTraffic(); setTimeout(autoHeal, 1500);
}
function disconnect() { return new Promise(res => { if (!proc) return res(); const p = proc; p.once('exit', () => res()); p.kill(); setTimeout(() => { try { execFile('taskkill', ['/F', '/PID', String(p.pid)]); } catch { } }, 2500); }); }
async function restart() { const was = !!proc; await disconnect(); if (was) await connect(); }

let trafReq;
function startTraffic() {
  trafReq = http.get({ host: '127.0.0.1', port: API, path: '/traffic' }, r => {
    let buf = ''; r.on('data', c => { buf += c; const lines = buf.split('\n'); buf = lines.pop(); for (const l of lines) { try { const t = JSON.parse(l); traffic = t; session.up += t.up; session.down += t.down; state.stats.totalUp += t.up; state.stats.totalDown += t.down; send('traffic', { ...t, session }); } catch { } } });
  }); trafReq.on('error', () => { });
  clearInterval(startTraffic.t); startTraffic.t = setInterval(async () => { save(); try { const c = await api('GET', '/connections'); send('conns', (c.connections || []).length); } catch { } }, 3000);
}
function stopTraffic() { try { trafReq && trafReq.destroy(); } catch { } clearInterval(startTraffic.t); traffic = { up: 0, down: 0 }; send('traffic', { up: 0, down: 0, session }); }

ipcMain.handle('vpn:toggle', async () => { if (proc) { state.wasOn = false; save(); await disconnect(); } else { await connect(); state.wasOn = true; save(); } return status; });
ipcMain.handle('vpn:mode', async (_, m) => { state.mode = m; save(); if (proc) await restart(); updateTray(); return pub(); });
ipcMain.handle('vpn:select', async (_, tag) => {
  state.selected = tag; save();
  if (proc) { try { await api('PUT', '/proxies/proxy', { name: tag }); log('— Сервер: ' + (allNodes().find(n => n.tag === tag)?.name || tag)); setTimeout(updateReal, 800); } catch { await restart(); } }
  updateTray(); return pub();
});

// Настоящий пинг всех серверов: через каждый сервер открываем одно соединение (CONNECT),
// первый запрос «прогревает» его, время второго — чистая задержка, как у открытого соединения.
const net = require('net');
function realVia(port, t = 6000) {
  return new Promise(res => {
    const sock = net.connect(port, '127.0.0.1'); let buf = '', stage = 0, t0 = 0, best = -1;
    const done = v => { clearTimeout(tm); sock.destroy(); res(v); };
    const tm = setTimeout(() => done(best), t);
    const get = () => { buf = ''; t0 = Date.now(); sock.write('GET /generate_204 HTTP/1.1\r\nHost: cp.cloudflare.com\r\nConnection: keep-alive\r\n\r\n'); };
    sock.on('connect', () => sock.write('CONNECT cp.cloudflare.com:80 HTTP/1.1\r\nHost: cp.cloudflare.com:80\r\n\r\n'));
    sock.on('data', d => {
      buf += d.toString('latin1');
      if (stage === 0) { if (!buf.includes('\r\n\r\n')) return; if (!/^HTTP\/1\.\d 200/.test(buf)) return done(-1); stage = 1; return get(); }
      if (!/\r\n\r\n/.test(buf)) return;
      const ms = Date.now() - t0;
      if (stage >= 2) best = best < 0 ? ms : Math.min(best, ms);
      if (++stage <= 3) get(); else done(best);
    });
    sock.on('error', () => done(best)); sock.on('close', () => done(best));
  });
}
let testProc = null;
ipcMain.handle('vpn:ping', async (_, tags) => {
  const nodes = allNodes(); tags = (tags && tags.length ? tags : nodes.map(n => n.tag)).filter(t => { const n = nodes.find(x => x.tag === t); return n && (n.ob || hasXray()); });
  const other = !proc && otherVpn();
  const cfg = core.buildConfig({ ...state, nodes }, { test: true, apiPort: TEST_API, hasXray: hasXray() });
  const use = core.usable(nodes, hasXray()); const PB = 22100;
  cfg.inbounds = use.map((n, i) => ({ type: 'mixed', tag: 'pin-' + i, listen: '127.0.0.1', listen_port: PB + i }));
  cfg.route.rules = use.map((n, i) => ({ inbound: ['pin-' + i], outbound: n.tag }));
  if (!proc) startXray(nodes);
  const file = path.join(DATA, 'test.json'); writeConfig(file, cfg);
  if (testProc) testProc.kill();
  testProc = spawn(SB, ['run', '-c', file], { windowsHide: true, cwd: path.dirname(SB) });
  for (let i = 0; i < 40; i++) { await new Promise(r => setTimeout(r, 200)); try { await api('GET', '/version', null, TEST_API, 1000); break; } catch { } }
  const full = state.settings.pingMode === 'full';
  await Promise.all(tags.map(async tag => {
    const i = use.findIndex(n => n.tag === tag); const ms = i < 0 ? -1 : full ? await delay(tag, TEST_API, 5000) : await realVia(PB + i);
    const n = state.subs.flatMap(s => s.nodes).find(x => x.tag === tag); if (n) n.ping = ms;
    send('ping', { tag, ms });
  }));
  if (testProc) { testProc.kill(); testProc = null; if (!proc) stopXray(); }
  updateTray(); save(); return { ...pub(), warn: other ? 'Пока включён ' + other + ', пинг показывается неверно' : null };
});

// ---------- правила ----------
ipcMain.handle('rule:add', async (_, r) => { if (r.preset === 'steam') r.action = 'direct'; r.id = 'r' + Date.now().toString(36); state.rules.unshift(r); save(); if (proc) await restart(); return pub(); });
ipcMain.handle('rule:update', async (_, r) => {
  const i = state.rules.findIndex(x => x.id === r.id); if (i < 0) return pub();
  const only = Object.keys(r).every(k => k === 'id' || k === 'action'); state.rules[i] = { ...state.rules[i], ...r }; save();
  if (proc) { if (only) { try { await api('PUT', '/proxies/rule-' + r.id, { name: r.action === 'direct' ? 'direct' : 'proxy' }); } catch { await restart(); } } else await restart(); }
  return pub();
});
ipcMain.handle('rule:reorder', (_, ids) => { const m = new Map(state.rules.map(r => [r.id, r])); state.rules = ids.map(id => m.get(id)).filter(Boolean).concat(state.rules.filter(r => !ids.includes(r.id))); save(); return pub(); });
ipcMain.handle('rule:remove', async (_, id) => { state.rules = state.rules.filter(x => x.id !== id); save(); if (proc) await restart(); return pub(); });
ipcMain.handle('rule:pickExe', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Выберите программу', filters: [{ name: 'Программы', extensions: ['exe'] }], properties: ['openFile'] });
  if (r.canceled) return null; const exe = r.filePaths[0]; const folder = path.dirname(exe);
  let exes = []; try { exes = fs.readdirSync(folder).filter(f => f.toLowerCase().endsWith('.exe')); } catch { }
  const low = path.basename(exe).toLowerCase(); const preset = Object.keys(core.APP_PRESETS).find(k => core.APP_PRESETS[k].process.includes(low));
  return { exe: path.basename(exe), exePath: exe, folder, process: exes.length ? exes : [path.basename(exe)], name: preset ? core.APP_PRESETS[preset].name : path.basename(exe, '.exe'), preset };
});

// список установленных программ: ярлыки меню «Пуск» + реестр, кэш на диске, иконки
const APPS_FILE = path.join(DATA, 'apps.json'); let appsCache = null, appsJob = null;
try { appsCache = JSON.parse(fs.readFileSync(APPS_FILE, 'utf8')); } catch { }
const BAD_EXE = /unins|uninst|setup|install|update|crash|report|helper|elevat|vc_?redist|dotnet/i;
const BAD_NAME = /^(настройки|параметры|settings)$|поддержка программ apple|фото icloud|apple mobile device|bing|bonjour|cross ?device|desktop ?app ?install|electron|get ?help|^help$|game ?bar|gaming ?services|frameview|\bsdk\b|^pages$|^photos$|фотографии|realtek|registry|редактор реестра|^tar$|screen ?sketch|snipping|^sets$|^ui$|start ?experience|xbox|^windows|web ?experience|winapp|detour|^main\b|runtime|redistributable|driver|\.net|ms-resource|^microsoft\.|widgets|copilot|cortana|feedback|tips|people|^camera$|clipchamp|outlook \(new\)|todo|sound ?recorder|calculator|калькулятор|notepad|блокнот|paint|терминал|terminal|powershell|command prompt|командная строка|control panel|панель управления|task manager|диспетчер|sechealth|storepurchase|yourphone|^python [0-9.]+ (64-bit)$/i;
async function scanApps() {
  const found = new Map();
  const add = (name, exe, logo) => { if (!exe || !/\.exe$/i.test(exe) || BAD_EXE.test(path.basename(exe)) || /\\windows\\(system32|syswow64)\\/i.test(exe)) return; const k = name.toLowerCase(); if (BAD_NAME.test(name.trim())) return; if (!found.has(k) && fs.existsSync(exe)) found.set(k, { name, exe, logo }); };
  const walk = dir => { let l = []; try { l = fs.readdirSync(dir, { withFileTypes: true }); } catch { } for (const e of l) { const p = path.join(dir, e.name); if (e.isDirectory()) walk(p); else if (/\.lnk$/i.test(e.name)) { try { const t = shell.readShortcutLink(p).target; add(e.name.replace(/\.lnk$/i, ''), t); } catch { } } } };
  walk(path.join(process.env.ProgramData || 'C:\\ProgramData', 'Microsoft', 'Windows', 'Start Menu', 'Programs'));
  walk(path.join(process.env.APPDATA, 'Microsoft', 'Windows', 'Start Menu', 'Programs'));
  walk(path.join(os.homedir(), 'Desktop')); walk('C:\\Users\\Public\\Desktop');
  const ps = "[Console]::OutputEncoding=[Text.Encoding]::UTF8; $k='HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*','HKLM:\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*','HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*'; Get-ItemProperty $k -ErrorAction SilentlyContinue | ? { $_.DisplayName -and -not $_.SystemComponent } | select DisplayName,DisplayIcon,InstallLocation | ConvertTo-Json -Compress";
  const out = await new Promise(r => execFile('powershell', ['-NoProfile', '-Command', ps], { windowsHide: true, maxBuffer: 1 << 24 }, (e, o) => r(o || '[]')));
  let list = []; try { list = JSON.parse(out); if (!Array.isArray(list)) list = [list]; } catch { }
  for (const a of list) {
    let exe = (a.DisplayIcon || '').replace(/"/g, '').replace(/,\s*-?\d+$/, '').trim();
    if (!/\.exe$/i.test(exe) || BAD_EXE.test(path.basename(exe))) { exe = ''; const folder = (a.InstallLocation || '').replace(/"/g, '').replace(/\\$/, ''); if (folder) { try { const f = fs.readdirSync(folder).filter(x => /\.exe$/i.test(x) && !BAD_EXE.test(x)); if (f.length) exe = path.join(folder, f[0]); } catch { } } }
    add(a.DisplayName, exe);
  }
  // Store-приложения, запущенные программы, папки установки в профиле
  const ps2 = "[Console]::OutputEncoding=[Text.Encoding]::UTF8; $o=@(); Get-AppxPackage -User ramaz -ErrorAction SilentlyContinue | ? { -not $_.IsFramework -and $_.SignatureKind -ne 'System' } | % { try { $m=[xml](Get-Content (Join-Path $_.InstallLocation 'AppxManifest.xml') -Raw); foreach($ap in $m.Package.Applications.Application){ if($ap.Executable){ $n=$m.Package.Properties.DisplayName; if($n -like 'ms-resource*'){ $n=$_.Name.Split('.')[-1] }; $lg=$ap.VisualElements.Square44x44Logo; $lp=''; if($lg){ $b=Join-Path $_.InstallLocation $lg; $dir=Split-Path $b; $nm=[IO.Path]::GetFileNameWithoutExtension($b); $c=Get-ChildItem $dir -Filter ($nm+'*.png') -ErrorAction SilentlyContinue | sort Length -Descending | select -First 1; if($c){$lp=$c.FullName} }; $o+=[pscustomobject]@{n=$n;e=(Join-Path $_.InstallLocation $ap.Executable);l=$lp} } } } catch {} }; Get-Process | ? { $_.Path -and $_.MainWindowHandle -ne 0 } | % { $d=$_.Description; if(-not $d){$d=$_.ProcessName}; $o+=[pscustomobject]@{n=$d;e=$_.Path} }; $o | ConvertTo-Json -Compress";
  const out2 = await new Promise(r => execFile('powershell', ['-NoProfile', '-Command', ps2], { windowsHide: true, maxBuffer: 1 << 24 }, (e, o) => r(o || '[]')));
  try { let l2 = JSON.parse(out2); if (!Array.isArray(l2)) l2 = [l2]; for (const x of l2) if (x && x.n && x.e && !/windows.(system32|syswow64|systemapps)/i.test(x.e)) add(String(x.n), x.e, x.l || ''); } catch { }
  for (const base of [path.join(process.env.LOCALAPPDATA || '', 'Programs'), process.env.APPDATA || '', process.env.LOCALAPPDATA || '']) {
    let ds = []; try { ds = fs.readdirSync(base, { withFileTypes: true }).filter(d => d.isDirectory()); } catch { }
    for (const d of ds) { let fl = []; try { fl = fs.readdirSync(path.join(base, d.name)).filter(f => /\.exe$/i.test(f) && !BAD_EXE.test(f)); } catch { } const pick = fl.find(f => f.toLowerCase().startsWith(d.name.toLowerCase().split(/[\s._-]/)[0])) || (fl.length === 1 ? fl[0] : null); if (pick) add(d.name, path.join(base, d.name, pick)); }
  }
  const res = [...found.values()];
  // дубли одного exe — оставляем короткое имя
  const byExe = new Map(); for (const r of res) { const k = r.exe.toLowerCase(); if (!byExe.has(k) || r.name.length < byExe.get(k).name.length) byExe.set(k, r); }
  const apps = [...byExe.values()];
  await Promise.all(apps.map(async a => {
    a.icon = '';
    if (a.logo) { try { a.icon = 'data:image/png;base64,' + fs.readFileSync(a.logo).toString('base64'); } catch { } }
    if (!a.icon) { try { const im = nativeImage.createFromPath(a.exe); if (!im.isEmpty()) a.icon = im.resize({ width: 32 }).toDataURL(); } catch { } }
    if (!a.icon) { try { const im = await app.getFileIcon(a.exe, { size: 'large' }); if (!im.isEmpty()) a.icon = im.toDataURL(); } catch { } }
    delete a.logo;
  }));
  for (let i = apps.length - 1; i >= 0; i--) if (!apps[i].icon || apps[i].icon.length < 400) apps.splice(i, 1);
  apps.sort((a, b) => a.name.localeCompare(b.name, 'ru'));
  appsCache = apps; try { fs.writeFileSync(APPS_FILE, JSON.stringify(apps)); } catch { }
  for (const k in iconMemo) delete iconMemo[k];
  send('apps', apps); return apps;
}
const refreshApps = () => appsJob || (appsJob = scanApps().finally(() => { appsJob = null; }));
ipcMain.handle('apps:list', async () => { if (appsCache) { refreshApps(); return appsCache; } return refreshApps(); });
// иконки для правил: путь программы или exe пресета из списка программ
const iconMemo = {};
ipcMain.handle('rule:icons', async () => {
  const out = {}; const apps = appsCache || [];
  for (const r of state.rules) {
    if (r.kind === 'site') continue;
    let exe = r.exePath;
    if (!exe) { const procs = [...(r.preset && core.APP_PRESETS[r.preset] ? core.APP_PRESETS[r.preset].process : []), ...(r.process || [])].map(x => x.toLowerCase());
      const hit = apps.find(a => procs.includes(path.basename(a.exe).toLowerCase())) || (r.folder && procs[0] && { exe: path.join(r.folder, procs[0]) });
      if (hit) exe = hit.exe; }
    const ap = apps.find(a => exe && a.exe.toLowerCase() === exe.toLowerCase()); if (ap && ap.icon) { out[r.id] = ap.icon; continue; }
    if (!exe) continue;
    if (!iconMemo[exe]) { try { iconMemo[exe] = (await app.getFileIcon(exe, { size: 'normal' })).toDataURL(); } catch { iconMemo[exe] = ''; } }
    if (iconMemo[exe]) out[r.id] = iconMemo[exe];
  }
  return out;
});
ipcMain.handle('rule:fromExe', (_, exe) => {
  const folder = path.dirname(exe); let exes = []; try { exes = fs.readdirSync(folder).filter(f => f.toLowerCase().endsWith('.exe')); } catch { }
  const low = path.basename(exe).toLowerCase(); const preset = Object.keys(core.APP_PRESETS).find(k => core.APP_PRESETS[k].process.includes(low));
  return { exe: path.basename(exe), exePath: exe, folder, process: exes.length ? exes : [path.basename(exe)], name: preset ? core.APP_PRESETS[preset].name : path.basename(exe, '.exe'), preset };
});

// ---------- игры Steam: всё установленное в библиотеке, у каждой игры свой маршрут ----------
let steamRoot, steamSig = ''; const steamIcons = {};
function steamDir() {
  if (steamRoot !== undefined) return steamRoot; steamRoot = '';
  const c = [];
  try { const o = require('child_process').execFileSync('reg', ['query', 'HKCU\\Software\\Valve\\Steam', '/v', 'SteamPath'], { windowsHide: true, encoding: 'utf8' }); const m = o.match(/SteamPath\s+REG_SZ\s+(.+)/); if (m) c.push(m[1].trim()); } catch { }
  c.push('C:\\Program Files (x86)\\Steam', 'C:\\Program Files\\Steam', 'D:\\Steam', 'D:\\Program Files (x86)\\Steam');
  for (const p of c) if (fs.existsSync(path.join(p, 'steamapps'))) { steamRoot = path.normalize(p); break; }
  return steamRoot;
}
function steamGames() {
  const root = steamDir(); if (!root) { steamRoot = undefined; return []; }
  const libs = new Set([root]);
  try { for (const m of fs.readFileSync(path.join(root, 'steamapps', 'libraryfolders.vdf'), 'utf8').matchAll(/"path"\s+"([^"]+)"/g)) libs.add(path.normalize(m[1].replace(/\\\\/g, '\\'))); } catch { }
  const res = [], seen = new Set();
  for (const lib of libs) {
    let fl = []; try { fl = fs.readdirSync(path.join(lib, 'steamapps')).filter(f => /^appmanifest_\d+\.acf$/i.test(f)); } catch { }
    for (const f of fl) {
      try {
        const t = fs.readFileSync(path.join(lib, 'steamapps', f), 'utf8'); const get = k => (t.match(new RegExp('"' + k + '"\\s+"([^"]*)"')) || [])[1];
        const appid = get('appid'), name = get('name'), dir = get('installdir'); if (!appid || !name || !dir || appid === '228980' || seen.has(appid)) continue;
        const folder = path.join(lib, 'steamapps', 'common', dir); if (!fs.existsSync(folder)) continue;
        seen.add(appid); res.push({ appid, name, folder });
      } catch { }
    }
  }
  return res.sort((a, b) => a.name.localeCompare(b.name, 'ru'));
}
const steamKey = () => steamGames().map(g => g.appid).join(',');
function steamIcon(appid) {
  if (appid in steamIcons) return steamIcons[appid]; let ic = '';
  try { const d = path.join(steamDir(), 'appcache', 'librarycache'); const f = fs.readdirSync(path.join(d, appid)).find(x => /^[0-9a-f]{40}\.jpg$/i.test(x)); const p = f ? path.join(d, appid, f) : path.join(d, appid + '_icon.jpg'); ic = 'data:image/jpeg;base64,' + fs.readFileSync(p).toString('base64'); } catch { }
  return steamIcons[appid] = ic;
}
// новая игра установлена/удалена — пересобрать правила, иначе она пойдёт через VPN
const steamCheck = () => { if (proc && status === 'on' && state.mode !== 'global' && state.rules.some(r => r.preset === 'steam' && r.enabled !== false) && steamKey() !== steamSig) restart(); };
setInterval(steamCheck, 120000);
ipcMain.handle('steam:games', () => { const r = state.rules.find(x => x.preset === 'steam'); const g = (r && r.games) || {}; setTimeout(steamCheck, 0); return steamGames().map(x => ({ appid: x.appid, name: x.name, icon: steamIcon(x.appid), action: g[x.appid] === 'proxy' ? 'proxy' : 'direct' })); });
ipcMain.handle('rule:game', async (_, { id, appid, action }) => {
  const r = state.rules.find(x => x.id === id); if (!r) return pub();
  r.games = { ...(r.games || {}), [appid]: action === 'proxy' ? 'proxy' : 'direct' }; save();
  if (proc) { try { await api('PUT', '/proxies/rule-' + id + '-g' + appid, { name: r.games[appid] }); } catch { await restart(); } }
  return pub();
});

// ---------- настройки ----------
ipcMain.handle('settings:set', async (_, patch) => {
  const prev = { ...state.settings }; Object.assign(state.settings, patch); save();
  if ('autostart' in patch) setAutostart(patch.autostart);
  if ('icon' in patch) applyIcon();
  if ('glass' in patch) applyGlass();
  if ('style' in patch && patch.style !== prev.style && win) delete state.winBounds, win.setSize(...SIZES[patch.style] || SIZES.classic, true);
  if (proc && ['ruDirect', 'stack', 'logLevel'].some(k => k in patch && patch[k] !== prev[k])) await restart();
  return pub();
});
ipcMain.handle('state', () => pub());
ipcMain.handle('logs', () => logs);
ipcMain.handle('logs:clear', () => { logs = []; });
ipcMain.handle('stats:reset', () => { state.stats = { totalUp: 0, totalDown: 0, sessions: 0 }; save(); return pub(); });
ipcMain.on('win', (_, a) => { if (a === 'min') win.minimize(); else if (a === 'close') onClose(); });
ipcMain.handle('presets', () => Object.fromEntries(Object.entries(core.APP_PRESETS).map(([k, v]) => [k, v.name])));
ipcMain.handle('open', (_, u) => shell.openExternal(u));

function pub() {
  return { subs: state.subs.map(s => ({ ...s, nodes: s.nodes.map(({ ob, xr, ...n }) => ({ ...n, server: (ob || xr).server, off: !ob && !hasXray() })) })), hasXray: hasXray(), otherVpn: otherVpn(), selected: state.selected, mode: state.mode, rules: state.rules, settings: state.settings, stats: state.stats, status, session };
}

// ---------- автозапуск (задача планировщика с правами админа, нужна для TUN) ----------
function setAutostart(on) {
  const ps = `$t = Get-ScheduledTask -TaskName '${TASK}' -ErrorAction SilentlyContinue; if ($t) { if (${on ? '$true' : '$false'}) { Set-ScheduledTask -TaskName '${TASK}' -Trigger (New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME) } else { Set-ScheduledTask -TaskName '${TASK}' -Trigger @() } }`;
  execFile('powershell', ['-NoProfile', '-Command', ps], { windowsHide: true }, e => e && log('Автозапуск: ' + e.message));
}

// ---------- иконки / трей ----------
const iconPath = (name, ext = 'png') => path.join(ROOT, 'assets', 'icons', `${name}.${ext}`);
function applyIcon() {
  const n = state.settings.icon; const img = nativeImage.createFromPath(iconPath(n));
  if (win) win.setIcon(img); updateTray();
  const ico = iconPath(n, 'ico');
  const ps = `$s=(New-Object -ComObject WScript.Shell); foreach($p in @(([Environment]::GetFolderPath('Desktop')+'\\Storm 2.0.lnk'), ($env:APPDATA+'\\Microsoft\\Windows\\Start Menu\\Programs\\Storm 2.0.lnk'))){ if(Test-Path $p){ $l=$s.CreateShortcut($p); $l.IconLocation='${ico},0'; $l.Save() } }; ie4uinit.exe -show`;
  execFile('powershell', ['-NoProfile', '-Command', ps], { windowsHide: true }, () => { });
}
function updateTray() {
  if (!tray) return;
  const on = status === 'on';
  tray.setImage(nativeImage.createFromPath(iconPath(state.settings.icon + (on ? '' : '-off'))).resize({ width: 16, height: 16 }));
  const node = allNodes().find(n => n.tag === state.selected);
  setTip();
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: on ? 'Отключить' : 'Подключить', click: () => (proc ? disconnect() : connect().catch(e => log('Ошибка: ' + e.message))) },
    { type: 'separator' },
    ...state.subs.map(sb => ({ label: sb.name, submenu: sb.nodes.filter(n => n.ob || hasXray()).map(n => ({ label: n.name.replace(/[\u{1F1E6}-\u{1F1FF}]/gu, '').replace(/^\s*\p{Extended_Pictographic}\uFE0F?\s*/u, '').trim() + (n.ping > 0 ? '   ' + n.ping + ' мс' : n.ping != null ? '   нет ответа' : ''), type: 'radio', checked: n.tag === state.selected, click: () => selectNode(n.tag) })) })),
    { type: 'separator' },
    { label: 'По правилам', type: 'radio', checked: state.mode !== 'global', click: () => setMode('rules') },
    { label: 'Всё через VPN', type: 'radio', checked: state.mode === 'global', click: () => setMode('global') },
    { type: 'separator' },
    { label: 'Открыть', click: showWin },
    { label: 'Выход', click: () => { quitting = true; app.quit(); } },
  ]));
}
async function setMode(m) { state.mode = m; save(); if (proc) await restart(); send('state', pub()); updateTray(); }
function showWin() { if (!win) createWin(); win.show(); win.focus(); }
function onClose() { if (state.settings.closeToTray) win.hide(); else { quitting = true; app.quit(); } }

function createWin() {
  win = new BrowserWindow({
    width: (SIZES[state.settings.style] || SIZES.classic)[0], height: (SIZES[state.settings.style] || SIZES.classic)[1], resizable: false, maximizable: false, fullscreenable: false, frame: false, show: false, backgroundColor: state.settings.theme === 'light' ? '#f3f4f8' : '#0a0b0f',
    icon: iconPath(state.settings.icon), webPreferences: { preload: path.join(ROOT, 'preload.js') },
  });
  const wb = state.winBounds;
  if (wb) { wb.width = 340; wb.height = 540; } // размер окна постоянный
  if (wb && screen.getAllDisplays().some(d => { const a = d.workArea; return wb.x < a.x + a.width - 40 && wb.x + wb.width > a.x + 40 && wb.y >= a.y - 10 && wb.y < a.y + a.height - 40; })) win.setBounds(wb);
  const keep = () => { if (!win.isMinimized() && !win.isMaximized()) { state.winBounds = win.getBounds(); save(); } };
  win.on('moved', keep); win.on('resized', keep); win.on('hide', keep);
  try { win.setAppDetails({ appId: 'StormVPN', appIconPath: iconPath(state.settings.icon, 'ico'), relaunchCommand: `wscript.exe "${path.join(ROOT, 'launch.vbs')}"`, relaunchDisplayName: 'Storm 2.0' }); } catch { }
  win.loadFile(path.join(ROOT, 'renderer', 'index.html'));
  if (state.settings.pinTop) win.setAlwaysOnTop(true, 'screen-saver');
  applyGlass();
  win.once('ready-to-show', () => { if (!process.argv.includes('--hidden')) win.show(); });
  win.on('close', e => { if (!quitting) { e.preventDefault(); onClose(); } });
}

app.on('second-instance', showWin);
app.whenReady().then(async () => {
  if (!state.taskPrio) execFile('powershell', ['-NoProfile', '-Command', "$t=Get-ScheduledTask -TaskName '" + TASK + "'; $t.Settings.Priority=4; Set-ScheduledTask -InputObject $t | Out-Null"], { windowsHide: true }, e => { if (!e) { state.taskPrio = 1; save(); } });
  Menu.setApplicationMenu(Menu.buildFromTemplate([{ role: 'editMenu' }]));
  app.setAppUserModelId('StormVPN');
  createWin();
  tray = new Tray(nativeImage.createFromPath(iconPath(state.settings.icon + '-off')).resize({ width: 16, height: 16 }));
  tray.on('click', showWin); updateTray();
  setTimeout(refreshApps, 4000);
  setTimeout(checkUpdate, 20000); setInterval(checkUpdate, 3 * 3600e3);
  // автообновление подписок старше 12 часов
  for (const s of state.subs) fetchSub(s).then(() => { save(); send('state', pub()); }).catch(() => { });
  if (state.zapret && state.zapret.on) zStart(state.zapret.strat).catch(e => log('Запрет: ' + e.message));
  if ((state.settings.autoConnect || state.wasOn !== false) && allNodes().length) (async () => { for (let k = 0; k < 6 && !proc; k++) { try { await connect(); } catch (e) { log('Ошибка: ' + e.message + ' — повтор'); await new Promise(r => setTimeout(r, 1000)); } } })();
});
app.on('window-all-closed', e => e.preventDefault());

// ── Автообновление: раз в 3 часа смотрит latest.json на GitHub; если версия новее — качает код, ставит и перезапускается (VPN сам переподключится)
const UPD = 'https://raw.githubusercontent.com/ramazan19575-del/storm2-updates/main/latest.json';
const APP_VER = require('./package.json').version;
const verGt = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; };
let updBusy = false;
async function checkUpdate() {
  if (updBusy || fs.existsSync(path.join(ROOT, '.dev'))) return; updBusy = true;
  try {
    const j = await (await fetch(UPD + '?t=' + Date.now(), { signal: AbortSignal.timeout(15000) })).json();
    if (!j.version || !j.url || !verGt(j.version, APP_VER)) return;
    log('Обновление ' + APP_VER + ' → ' + j.version);
    const buf = Buffer.from(await (await fetch(j.url, { signal: AbortSignal.timeout(180000) })).arrayBuffer());
    if (j.sha256 && crypto.createHash('sha256').update(buf).digest('hex') !== j.sha256) throw new Error('контрольная сумма не совпала');
    const tmp = path.join(os.tmpdir(), 'storm-upd'); fs.rmSync(tmp, { recursive: true, force: true }); fs.mkdirSync(tmp, { recursive: true });
    fs.writeFileSync(path.join(tmp, 'u.zip'), buf);
    await new Promise((res, rej) => execFile(path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe'), ['-xf', 'u.zip'], { cwd: tmp, windowsHide: true }, e => e ? rej(e) : res()));
    if (!fs.existsSync(path.join(tmp, 'main.js')) || !fs.existsSync(path.join(tmp, 'package.json'))) throw new Error('битый архив');
    fs.rmSync(path.join(tmp, 'u.zip'));
    fs.cpSync(tmp, ROOT, { recursive: true, force: true });
    state.wasOn = !!proc; save();
    send('toast', 'Storm обновлён до ' + j.version + ' — перезапуск');
    spawn('cmd.exe', ['/c', 'timeout /t 3 /nobreak >nul & schtasks /run /tn "' + TASK + '"'], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
    setTimeout(() => app.quit(), 1500);
  } catch (e) { log('Обновление: ' + e.message); } finally { updBusy = false; }
}
ipcMain.handle('app:version', () => APP_VER);
app.on('before-quit', () => { zStop(); quitting = true; fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 1)); if (proc) proc.kill(); if (testProc) testProc.kill(); stopXray(); });

// ---------- буфер обмена и QR ----------
const LINK = /(https?:\/\/[^\s"'<>]+|(?:vless|vmess|trojan|ss|hysteria2|hy2|tuic):\/\/[^\s"'<>]+)/i;
function scanQR(img) {
  if (!img || img.isEmpty()) return null; const { width, height } = img.getSize(); const b = img.toBitmap(); const d = new Uint8ClampedArray(b.length);
  for (let i = 0; i < b.length; i += 4) { d[i] = b[i + 2]; d[i + 1] = b[i + 1]; d[i + 2] = b[i]; d[i + 3] = 255; }
  const r = jsQR(d, width, height); return r && r.data ? r.data.trim() : null;
}
ipcMain.handle('clip:read', () => {
  const t = clipboard.readText().trim(); const links = t.split(/\r?\n/).map(s => s.trim()).filter(s => LINK.test(s));
  if (links.length) return { text: /^https?:/i.test(links[0]) ? links[0].match(LINK)[0] : links.join('\n'), from: 'буфера обмена' };
  const q = scanQR(clipboard.readImage()); if (q && LINK.test(q)) return { text: q, from: 'QR-кода в буфере' };
  return null;
});
ipcMain.handle('qr:screen', async () => {
  const wasVisible = win.isVisible(); win.hide(); await new Promise(r => setTimeout(r, 350));
  try {
    for (const d of screen.getAllDisplays()) {
      const size = { width: Math.round(d.size.width * d.scaleFactor), height: Math.round(d.size.height * d.scaleFactor) };
      const src = (await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: size })).find(s => String(s.display_id) === String(d.id)) ;
      const q = src && scanQR(src.thumbnail); if (q) return { text: q, from: 'QR-кода на экране' };
    }
    return null;
  } finally { if (wasVisible) win.show(); }
});
ipcMain.handle('qr:file', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Картинка с QR-кодом', filters: [{ name: 'Картинки', extensions: ['png', 'jpg', 'jpeg', 'bmp', 'webp'] }], properties: ['openFile'] });
  if (r.canceled) return null; const q = scanQR(nativeImage.createFromPath(r.filePaths[0])); return q ? { text: q, from: 'QR-кода' } : { error: 'QR-код на картинке не найден' };
});
ipcMain.handle('vpn:best', async () => {
  const best = state.subs.flatMap(s => s.nodes).filter(n => n.ping > 0).sort((a, b) => a.ping - b.ping)[0]; if (!best) return pub();
  state.selected = best.tag; save(); if (proc) { try { await api('PUT', '/proxies/proxy', { name: best.tag }); } catch { await restart(); } } updateTray(); return pub();
});

// ---------- ядро Xray (для серверов, которые sing-box не умеет) и чужие VPN ----------
let xproc = null;
function startXray(nodes) {
  stopXray(); if (!hasXray()) return; const xc = core.buildXray(nodes); if (!xc) return;
  const file = path.join(DATA, 'xray.json'); fs.writeFileSync(file, JSON.stringify(xc, null, 1));
  xproc = spawn(XR, ['run', '-c', file], { windowsHide: true, cwd: path.dirname(XR) });
  xproc.stdout.on('data', d => String(d).split('\n').forEach(l => l.trim() && log('[xray] ' + l)));
  xproc.stderr.on('data', d => String(d).split('\n').forEach(l => l.trim() && log('[xray] ' + l)));
  const p = xproc; p.on('exit', () => { if (xproc === p) xproc = null; });
}
function stopXray() { if (xproc) { try { xproc.kill(); } catch { } xproc = null; } }
function otherVpn() {
  const ifs = os.networkInterfaces(); const names = Object.keys(ifs).filter(n => !/^StormTun/i.test(n) && (ifs[n] || []).some(a => a.family === 'IPv4' && !a.address.startsWith('169.254.')));
  const hit = names.find(n => /incy|karing|happ|hiddify|wintun|sing-?box|nekoray|v2ray|outline|wireguard|amnezia|openvpn|^tun|^utun/i.test(n));
  if (!hit) return null; const k = hit.match(/incy|karing|happ|hiddify|amnezia|wireguard|openvpn|outline/i); return k ? k[0].toUpperCase() : hit;
}

// ---------- проверка после подключения ----------
async function delay(tag, port = API, t = 4000) {
  try { const r = await api('GET', `/proxies/${encodeURIComponent(tag)}/delay?timeout=${t}&url=${encodeURIComponent(state.settings.pingUrl)}`, null, port, t + 2000); return r.delay || -1; } catch { return -1; }
}
async function autoHeal() {
  if (!proc || status !== 'on') return;
  const cur = state.selected; const ms = await delay(cur); setPing(cur, ms);
  if (ms > 0) { log('— Проверка: сервер отвечает, ' + ms + ' мс'); updateReal(); return; }
  log('— Проверка: выбранный сервер не отвечает, ищу рабочий…');
  const nodes = core.usable(allNodes(), hasXray()).filter(n => n.tag !== cur);
  const res = await Promise.all(nodes.map(async n => [n, await delay(n.tag)]));
  res.forEach(([n, d]) => setPing(n.tag, d));
  const best = res.filter(r => r[1] > 0).sort((a, b) => a[1] - b[1])[0];
  if (best) { state.selected = best[0].tag; save(); try { await api('PUT', '/proxies/proxy', { name: best[0].tag }); } catch { } log('— Переключено на ' + best[0].name); send('state', pub()); send('notice', 'Сервер не отвечал — переключил на «' + best[0].name.replace(/[\u{1F1E6}-\u{1F1FF}]/gu, '').trim() + '»'); }
  else { log('— Ни один сервер не отвечает'); send('state', pub()); send('notice', otherVpn() ? 'Серверы не отвечают: мешает ' + otherVpn() : 'Ни один сервер не отвечает — проверьте интернет'); }
  updateTray();
}
function setPing(tag, ms) { const n = state.subs.flatMap(s => s.nodes).find(x => x.tag === tag); if (n) n.ping = ms; send('ping', { tag, ms }); }

// ---------- управление снаружи (Джарвис): http://127.0.0.1:9098 ----------
http.createServer(async (rq, rs) => {
  const u = new URL(rq.url, 'http://x'); let out = {};
  rs.setHeader('Access-Control-Allow-Origin', '*'); rs.setHeader('Content-Type', 'application/json; charset=utf-8');
  try {
    if (u.pathname === '/show') showWin();
    else if (u.pathname === '/restart') { state.wasOn = !!proc; save(); spawn('cmd.exe', ['/c', 'timeout /t 3 /nobreak >nul & schtasks /run /tn "' + TASK + '"'], { detached: true, stdio: 'ignore', windowsHide: true }).unref(); quitting = true; setTimeout(() => app.quit(), 500); }
    else if (u.pathname === '/reload') { if (win) win.webContents.reloadIgnoringCache(); }
    else if (u.pathname === '/toggle') { if (proc) { state.wasOn = false; save(); await disconnect(); } else { await connect(); state.wasOn = true; save(); } }
    else if (u.pathname === '/select') { const tag = u.searchParams.get('tag'); if (allNodes().some(n => n.tag === tag)) { state.selected = tag; save(); if (proc) { try { await api('PUT', '/proxies/proxy', { name: tag }); } catch { await restart(); } } send('state', pub()); updateTray(); } }
  } catch (e) { out.error = e.message; }
  const nodes = allNodes().filter(n => n.ob || hasXray()).map(n => ({ tag: n.tag, name: n.name, ping: n.ping ?? null }));
  rs.end(JSON.stringify({ ...out, status, selected: state.selected, nodes, session }));
}).on('error', () => { }).listen(9098, '127.0.0.1');

// ---------- настоящий пинг: запросы по уже открытому соединению через выбранный сервер ----------
function realPing() {
  return new Promise(res => {
    const agent = new http.Agent({ keepAlive: true, maxSockets: 1 }); const times = []; let n = 0;
    const one = () => {
      const t0 = process.hrtime.bigint();
      const rq = http.request({ host: 'cp.cloudflare.com', path: '/generate_204', agent, timeout: 4000 }, r => {
        r.resume(); r.on('end', () => { times.push(Number(process.hrtime.bigint() - t0) / 1e6); if (++n < 4) one(); else { agent.destroy(); const w = times.slice(1); res(w.length ? Math.round(Math.min(...w)) : -1); } });
      });
      rq.on('error', () => { agent.destroy(); res(times.length > 1 ? Math.round(Math.min(...times.slice(1))) : -1); });
      rq.on('timeout', () => rq.destroy()); rq.end();
    };
    one();
  });
}
async function updateReal() {
  if (!proc || status !== 'on' || state.settings.pingMode === 'full') return; const ms = await realPing(); if (ms > 0) setPing(state.selected, ms);
}


// ---------- подсказка трея: сервер, скорость, пинг ----------
function setTip() {
  if (!tray) return; const on = status === 'on'; const node = allNodes().find(n => n.tag === state.selected);
  const nm = node ? node.name.replace(/[\u{1F1E6}-\u{1F1FF}]/gu, '').replace(/^\s*\p{Extended_Pictographic}\uFE0F?\s*/u, '').trim() : '';
  const sp = b => b >= 1048576 ? (b / 1048576).toFixed(1) + ' МБ/с' : b >= 1024 ? Math.round(b / 1024) + ' КБ/с' : b + ' Б/с';
  let t = 'Storm 2.0 — ' + (on ? 'подключено' : status === 'connecting' ? 'подключение…' : 'отключено');
  if (nm) t += '\n' + nm + (on && node.ping > 0 ? ' · ' + node.ping + ' мс' : '');
  if (on) t += '\n↓ ' + sp(traffic.down || 0) + '   ↑ ' + sp(traffic.up || 0);
  tray.setToolTip(t.slice(0, 127));
}
setInterval(setTip, 2000);
// ---------- автопереключение: выбранный сервер тормозит/молчит больше минуты ----------
let slow = 0;
setInterval(async () => {
  if (!proc || status !== 'on') { slow = 0; return; }
  const ms = await realPing(); if (ms > 0) setPing(state.selected, ms);
  slow = (ms < 0 || ms > 900) ? slow + 1 : 0;
  if (slow < 4) return; slow = 0;
  const cur = state.selected; const best = state.subs.flatMap(s => s.nodes).filter(n => n.tag !== cur && n.ping > 0 && (n.ob || hasXray())).sort((a, b) => a.ping - b.ping)[0];
  if (!best) return;
  state.selected = best.tag; save(); try { await api('PUT', '/proxies/proxy', { name: best.tag }); } catch { }
  log('— Автопереключение на ' + best.name); send('state', pub()); send('notice', 'Сервер тормозил — переключил на «' + best.name.replace(/[\u{1F1E6}-\u{1F1FF}]/gu, '').trim() + '»'); updateTray();
}, 15000);

// ---------- значки сайтов (окну картинки из сети запрещены — качаем здесь, храним в data/favicons.json) ----------
const FAV_FILE = path.join(DATA, 'favicons.json'); let favs = {}; try { favs = JSON.parse(fs.readFileSync(FAV_FILE, 'utf8')); } catch { }
ipcMain.handle('favicon', async (_, d) => {
  if (favs[d]) return favs[d];
  for (const u of [`https://www.google.com/s2/favicons?domain=${d}&sz=64`, `https://icons.duckduckgo.com/ip3/${d}.ico`, `https://${d}/favicon.ico`]) {
    try { const r = await fetch(u, { signal: AbortSignal.timeout(6000) }); if (!r.ok) continue; const b = Buffer.from(await r.arrayBuffer()); if (b.length < 100) continue;
      const ct = r.headers.get('content-type') || 'image/png'; favs[d] = `data:${ct.split(';')[0]};base64,` + b.toString('base64'); fs.writeFileSync(FAV_FILE, JSON.stringify(favs)); return favs[d]; } catch { }
  }
  return '';
});
// ---------- закрепить окно поверх всех ----------
ipcMain.handle('pin', (_, v) => { state.settings.pinTop = v == null ? !state.settings.pinTop : !!v; save(); if (win) win.setAlwaysOnTop(state.settings.pinTop, 'screen-saver'); return state.settings.pinTop; });

// ---------- Запрет (zapret): Discord и YouTube без VPN ----------
const ZDIR = path.join(ROOT, 'zapret'), ZBIN = path.join(ZDIR, 'bin'), ZLISTS = path.join(ZDIR, 'lists');
let zproc = null, zBusy = false;
function zDomains() { try { return ['list-general.txt', 'list-general-user.txt'].flatMap(f => { try { return fs.readFileSync(path.join(ZLISTS, f), 'utf8').split(/\r?\n/); } catch { return []; } }).map(x => x.trim()).filter(x => x && !x.startsWith('#') && x.includes('.') && !/example/.test(x)); } catch { return ['youtube.com', 'youtu.be', 'googlevideo.com', 'ytimg.com', 'ggpht.com', 'discord.com', 'discord.gg', 'discordapp.com', 'discordapp.net', 'discord.media']; } }
function zList() { try { return fs.readdirSync(ZDIR).filter(f => /^general \(ALT\d*\)\.bat$/i.test(f)).map(f => f.replace(/\.bat$/i, '')).sort((a, b) => (+(a.match(/ALT(\d*)/)[1] || 1)) - (+(b.match(/ALT(\d*)/)[1] || 1))); } catch { return []; } }
function zArgs(name) {
  let t = fs.readFileSync(path.join(ZDIR, name + '.bat'), 'utf8'); const i = t.indexOf('winws.exe"'); if (i < 0) throw new Error('В файле нет запуска winws');
  t = t.slice(i + 10).replace(/\^\r?\n/g, ' ').split(/\r?\n/)[0];
  t = t.replace(/%BIN%/g, ZBIN + '\\').replace(/%LISTS%/g, ZLISTS + '\\').replace(/%GameFilter(TCP|UDP)?%/g, '12');
  const out = []; let cur = '', q = false, has = false;
  for (const c of t) { if (c === '"') { q = !q; has = true; continue; } if (!q && /\s/.test(c)) { if (cur || has) out.push(cur); cur = ''; has = false; continue; } cur += c; }
  if (cur || has) out.push(cur); return out;
}
function zStop() { if (zproc) { try { zproc.kill(); } catch { } zproc = null; } try { execFile('taskkill', ['/F', '/IM', 'winws.exe'], { windowsHide: true }, () => { }); } catch { } }
async function zStart(name) {
  const list = zList(); if (!list.length) throw new Error('Не найдена папка ' + ZDIR);
  if (!list.includes(name)) name = list[0];
  zStop(); await new Promise(r => setTimeout(r, 600));
  try { execFile('sc', ['stop', 'zapret'], { windowsHide: true }, () => { }); } catch { }
  const p = spawn(path.join(ZBIN, 'winws.exe'), zArgs(name), { cwd: ZBIN, windowsHide: true }); zproc = p;
  p.on('exit', c => { if (zproc === p) { zproc = null; log('Запрет остановлен (код ' + c + ')'); send('zapret', zPub()); } });
  state.zapret = { ...(state.zapret || {}), on: true, strat: name }; save(); await zRoute();
  log('Запрет: ' + name); send('zapret', zPub());
}
async function zRoute() { // мгновенно, без перезапуска VPN
  if (!proc) return; const v = state.zapret && state.zapret.on ? 'direct' : 'proxy';
  try { await api('PUT', '/proxies/zapret-route', { name: v }); } catch { if (state.zapret && state.zapret.on) await restart(); }
}
function lanIp() { const ifs = os.networkInterfaces(); for (const [n, l] of Object.entries(ifs)) { if (/tun|storm|happ|incy|karing|wintun|vpn|loopback|vethernet|virtual/i.test(n)) continue; const a = (l || []).find(x => x.family === 'IPv4' && !x.internal && !x.address.startsWith('169.254.')); if (a) return a.address; } return null; }
function probe(url, ip) {
  return new Promise(res => { const a = ['-s', '-o', 'NUL', '-m', '6', '-w', '%{http_code} %{time_total}', url]; if (ip) a.unshift('--interface', ip);
    execFile('curl.exe', a, { windowsHide: true }, (e, o) => { const [code, t] = String(o || '').trim().split(' '); res(+code > 0 ? Math.round(+t * 1000) : -1); }); });
}
async function zTest() { const ip = lanIp(); const [d1, d2, y1, y2, tg, wa] = await Promise.all([probe('https://discord.com/api/v9/gateway', ip), probe('https://gateway.discord.gg/', ip), probe('https://www.youtube.com/generate_204', ip), probe('https://redirector.googlevideo.com/report_mapping', ip), probe('https://web.telegram.org/', ip), probe('https://web.whatsapp.com/', ip)]);
  const d = d1 > 0 && d2 > 0 ? Math.max(d1, d2) : -1, y = y1 > 0 && y2 > 0 ? Math.max(y1, y2) : -1; const r = { discord: d, youtube: y, telegram: tg, whatsapp: wa, at: Date.now() }; state.zapret = { ...(state.zapret || {}), test: r }; save(); return r; }
const zPub = () => ({ ...(state.zapret || {}), running: !!zproc, list: zList(), dir: ZDIR, busy: zBusy });
ipcMain.handle('z:state', () => zPub());
ipcMain.handle('z:start', async (_, name) => { await zStart(name || (state.zapret && state.zapret.strat)); return zPub(); });
ipcMain.handle('z:stop', async () => { zStop(); state.zapret = { ...(state.zapret || {}), on: false }; save(); await zRoute(); send('zapret', zPub()); return zPub(); });
ipcMain.handle('z:test', async () => { await zTest(); return zPub(); });
ipcMain.handle('z:autoMode', async (_, v) => { state.zapret = { ...(state.zapret || {}), auto: !!v }; save(); if (v) { if (!zproc) await zStart(state.zapret.strat); zWatch(true); } send('zapret', zPub()); return zPub(); });
let zFails = 0;
async function zWatch(force) {
  if (zBusy || !state.zapret || !state.zapret.on) return;
  const t = await zTest(); send('zapret', zPub());
  if (!state.zapret.auto) return;
  zFails = (t.discord > 0 && t.youtube > 0) ? 0 : zFails + 1;
  if (zFails >= (force ? 1 : 2)) { zFails = 0; log('Запрет: способ перестал работать — подбираю'); await zAutoPick(state.zapret.strat); }
}
setInterval(() => zWatch(false), 20000);
async function zAutoPick(skip) {
  if (zBusy) return null; zBusy = true; let found = null; const list = zList(); const from = Math.max(0, list.indexOf(skip));
  try {
    for (const name of [...list.slice(from + 1), ...list.slice(0, from + 1)]) {
      send('zapret', { ...zPub(), testing: name });
      try { await zStart(name); } catch { continue; }
      await new Promise(r => setTimeout(r, 1500)); const t = await zTest();
      if (t.discord > 0 && t.youtube > 0) { found = name; break; }
    }
  } finally { zBusy = false; }
  if (found) send('notice', 'Запрет: переключил на ' + found.replace(/^general\s*\(?|\)$/g, '')); send('zapret', zPub()); return found;
}
ipcMain.handle('z:auto', async () => {
  if (zBusy) return zPub(); zBusy = true; let found = null;
  try {
    for (const name of zList()) {
      send('zapret', { ...zPub(), testing: name });
      try { await zStart(name); } catch { continue; }
      await new Promise(r => setTimeout(r, 1500)); const t = await zTest(); send('zapret', { ...zPub(), testing: name });
      if (t.discord > 0 && t.youtube > 0) { found = name; break; }
    }
    if (!found) { zStop(); state.zapret = { ...(state.zapret || {}), on: false }; save(); await zRoute(); }
  } finally { zBusy = false; }
  send('zapret', zPub()); return { ...zPub(), found };
});

async function selectNode(tag) { state.selected = tag; save(); if (proc) { try { await api('PUT', '/proxies/proxy', { name: tag }); setTimeout(updateReal, 800); } catch { await restart(); } } send('state', pub()); updateTray(); }
ipcMain.on('pingsDone', () => updateTray());
// ---------- проверка утечек: с какого IP тебя видят ----------
ipcMain.handle('myip', async () => {
  const get = async () => { for (const u of ['https://ipwho.is/', 'https://ipapi.co/json/']) { try { const r = await fetch(u, { signal: AbortSignal.timeout(7000) }); const j = await r.json(); return { ip: j.ip, country: j.country || j.country_name, cc: (j.country_code || '').toLowerCase(), city: j.city, org: (j.connection && (j.connection.org || j.connection.isp)) || j.org || '' }; } catch { } } return null; };
  const vpn = await get();
  const ip = lanIp(); const direct = await new Promise(res => execFile('curl.exe', ['-s', '-m', '6', '--interface', ip || '0.0.0.0', 'https://api.ipify.org'], { windowsHide: true }, (e, o) => res(String(o || '').trim() || null)));
  return { vpn, direct, leak: !!(proc && vpn && direct && vpn.ip === direct) };
});

// ---------- «Liquid Glass»: прозрачное окно с размытием Windows (акрил) ----------
function applyGlass() {
  if (!win) return; const on = !!state.settings.glass;
  try { win.setBackgroundColor(on ? '#00000000' : (state.settings.theme === 'light' ? '#f7f1e7' : '#0a0b0f')); } catch { }
  try { win.setBackgroundMaterial(on ? 'acrylic' : 'none'); } catch (e) { log('Стекло: ' + e.message); }
}
