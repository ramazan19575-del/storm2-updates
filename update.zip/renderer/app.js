const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const call = (c, a) => window.vpn.call(c, a);
let S = null, presets = {}, collapsed = JSON.parse(localStorage.collapsed || '{}'), hist = [], page = 'home';
const ICONS = ['night', 'snow', 'ocean', 'wblack', 'wwhite', 'wdark', 'wgray', 'wmint', 'wsunset', 'neon', 'sunset', 'graphite'];

// набор линейных иконок
const IC = {
  power: '<path d="M12 3v9"/><path d="M6.4 6.6a8 8 0 1 0 11.2 0"/>',
  home: '<path d="M4 11l8-7 8 7"/><path d="M6 10v9h12v-9"/>',
  layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
  chart: '<path d="M5 20V11"/><path d="M12 20V4"/><path d="M19 20v-6"/>',
  route: '<circle cx="6" cy="18" r="2.4"/><circle cx="18" cy="6" r="2.4"/><path d="M8.4 18H15a3 3 0 0 0 0-6H9a3 3 0 0 1 0-6h6.6"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  shieldz: '<path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6z"/><path d="M13 7.5L9.5 12.5h3L11 16.5l3.5-5h-3z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', x: '<path d="M6 6l12 12M18 6L6 18"/>', min: '<path d="M6 12h12"/>',
  refresh: '<path d="M20 11a8 8 0 0 0-14.5-3.5L4 9"/><path d="M4 4v5h5"/><path d="M4 13a8 8 0 0 0 14.5 3.5L20 15"/><path d="M20 20v-5h-5"/>',
  pulse: '<path d="M3 12h4l2.5-6 4 12 2.5-6h5"/>',
  star: '<path d="M13 3L5 13.5h6L10 21l8-10.5h-6z"/>',
  down: '<path d="M12 5v14M6 13l6 6 6-6"/>', up: '<path d="M12 19V5M6 11l6-6 6 6"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  trash: '<path d="M5 7h14M10 7V4.5h4V7M7 7l1 12.5h8L17 7"/>',
  globe: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c3 3.2 3 13.8 0 17M12 3.5c-3 3.2-3 13.8 0 17"/>',
  app: '<rect x="4" y="4" width="7" height="7" rx="2"/><rect x="13" y="4" width="7" height="7" rx="2"/><rect x="4" y="13" width="7" height="7" rx="2"/><rect x="13" y="13" width="7" height="7" rx="2"/>',
  paste: '<rect x="6" y="5" width="12" height="16" rx="2.5"/><path d="M9.5 5V3.5h5V5M9.5 11h5M9.5 15h5"/>',
  qr: '<rect x="4" y="4" width="6" height="6" rx="1.2"/><rect x="14" y="4" width="6" height="6" rx="1.2"/><rect x="4" y="14" width="6" height="6" rx="1.2"/><path d="M14 14h2.5v2.5M20 14v6h-6M17 20v-1"/>',
  image: '<rect x="3.5" y="5" width="17" height="14" rx="3"/><circle cx="9" cy="10" r="1.6"/><path d="M4.5 17l5-4.5 3.5 3 3-2.5 4 4"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  chev: '<path d="M9 6l6 6-6 6"/>', chevd: '<path d="M6 9l6 6 6-6"/>',
};
const svg = n => `<svg viewBox="0 0 24 24">${IC[n] || ''}</svg>`;
const paintIcons = (root = document) => root.querySelectorAll('[data-ic]').forEach(e => { if (e.dataset.done !== e.dataset.ic) { e.innerHTML = svg(e.dataset.ic); e.dataset.done = e.dataset.ic; } });

const fmt = b => { b = +b || 0; const u = ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ']; let i = 0; while (b >= 1024 && i < 4) { b /= 1024; i++; } return (i ? b.toFixed(1) : b) + ' ' + u[i]; };
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const ago = t => { if (!t) return 'ещё не обновлялась'; const m = Math.round((Date.now() - t) / 60000); return m < 1 ? 'только что' : m < 60 ? m + ' мин назад' : m < 1440 ? Math.round(m / 60) + ' ч назад' : Math.round(m / 1440) + ' дн назад'; };
function toast(t) { const el = $('#toast'); el.textContent = t; el.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove('show'), 2600); }
async function act(p) { try { const r = await p; if (r && r.subs) { S = r; render(); } return r; } catch (e) { toast(String(e.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '')); } }

// код страны из флага в названии, иначе первые буквы
function code(name) {
  const cp = [...name].map(c => c.codePointAt(0)).filter(c => c >= 0x1F1E6 && c <= 0x1F1FF);
  if (cp.length >= 2) return String.fromCharCode(cp[0] - 0x1F1E6 + 65, cp[1] - 0x1F1E6 + 65);
  const w = name.replace(/[^\p{L}\p{N} ]/gu, '').trim(); return (w.slice(0, 2) || '··').toUpperCase();
}
function avatar(name) {
  const cp = [...name].map(c => c.codePointAt(0)).filter(c => c >= 0x1F1E6 && c <= 0x1F1FF);
  if (cp.length >= 2 && cp[0] === 0x1F1F5 && cp[1] === 0x1F1F8) return `<div class="av flag"><img src="data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 6 6%27%3E%3Cpath fill=%27%23000%27 d=%27M0 0h6v2H0z%27/%3E%3Cpath fill=%27%23fff%27 d=%27M0 2h6v2H0z%27/%3E%3Cpath fill=%27%23149954%27 d=%27M0 4h6v2H0z%27/%3E%3Cpath fill=%27%23e4312b%27 d=%27M0 0l3.2 3L0 6z%27/%3E%3C/svg%3E"></div>`;
  if (cp.length >= 2) { const cc = String.fromCharCode(cp[0] - 0x1F1E6 + 97, cp[1] - 0x1F1E6 + 97); return `<div class="av flag"><img src="../node_modules/flag-icons/flags/1x1/${cc}.svg" onerror="this.parentNode.textContent='${cc.toUpperCase()}'"></div>`; }
  const hasFlag = [...name].some(c => { const p = c.codePointAt(0); return p >= 0x1F1E6 && p <= 0x1F1FF; });
  if (!hasFlag && /автовыбор|антизаглушк/i.test(name)) return `<div class="av flag"><img src="data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 100 100%27%3E%3Crect width=%27100%27 height=%27100%27 fill=%27%23fff%27/%3E%3Ccircle cx=%2750%27 cy=%2750%27 r=%2722%27 fill=%27%23bc002d%27/%3E%3C/svg%3E"></div>`;
  if (!hasFlag && /автовыбор/i.test(name)) return `<div class="av special auto"><svg viewBox="0 0 24 24"><path d="M13 3L5 13.5h6L10 21l8-10.5h-6z"/></svg></div>`;
  if (!hasFlag && /антизаглушк/i.test(name)) return `<div class="av special shield"><svg viewBox="0 0 24 24"><path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6z"/><path d="M9 12l2 2 4-4"/></svg></div>`;
  const em = name.match(/\p{Extended_Pictographic}/u); if (em) return `<div class="av emo">${em[0]}</div>`;
  return `<div class="av">${esc(code(name))}</div>`;
}
const clean = name => name.replace(/[\u{1F1E6}-\u{1F1FF}]/gu, '').replace(/^\s*\p{Extended_Pictographic}\uFE0F?\s*/u, '').trim() || name;

// ---------- навигация ----------
const ORDER = ['subs', 'zapret', 'stats', 'home', 'routes', 'settings', 'logs'];
function go(p) {
  const dir = ORDER.indexOf(p) >= ORDER.indexOf(page) ? 'r' : 'l';
  page = p; $$('.page').forEach(x => { const on = x.id === 'p-' + p; x.classList.toggle('active', on); x.classList.remove('in-r', 'in-l'); if (on) { void x.offsetWidth; x.classList.add('in-' + dir); } });
  $$('nav>button').forEach(x => x.classList.toggle('active', x.dataset.p === p));
  if (p === 'zapret') call('z:state').then(drawZ);
  if (p === 'logs') loadLogs(); if (p === 'stats') drawChart();
  updateFab();
}
function updateFab() {
  const power = page === 'home' && S && S.settings.pinConnect; const f = $('#fab');
  f.classList.toggle('power', power); $('#fabIc').dataset.ic = power ? 'power' : 'home';
  $('#fabLabel').textContent = power ? (S.status === 'on' ? 'Отключить' : S.status === 'connecting' ? 'Подключение' : 'Подключить') : 'Главная';
  paintIcons(f);
}
$$('nav>button').forEach(b => b.onclick = () => go(b.dataset.p));
$('#fab').onclick = () => { if ($('#fab').classList.contains('power')) toggle(); else if (page === 'home') $('#p-home').scrollTo({ top: 0, behavior: 'smooth' }); else go('home'); };
$('#bigBtn').onclick = () => toggle();
$('#openLogs').onclick = () => go('logs');
$('#homeSub').onclick = () => go('subs');
$$('.wbtn[data-w]').forEach(b => b.onclick = () => window.vpn.win(b.dataset.w));
$('#pinBtn').onclick = async () => { const v = await call('pin'); $('#pinBtn').classList.toggle('on', v); toast(v ? 'Storm поверх всех окон' : 'Закрепление снято'); };
async function toggle() { if (S.status === 'connecting') return; if (S.status === 'off' && !S.subs.length) return openAdd(); const r = await act(call('vpn:toggle')); if (r) setStatus(r); }

function applyTheme() {
  const t = S.settings.theme; const light = t === 'light' || (t === 'system' && matchMedia('(prefers-color-scheme: light)').matches);
  document.body.classList.toggle('light', light); document.body.classList.toggle('compact', S.settings.style === 'compact');
  document.body.classList.toggle('unpinned', !S.settings.pinConnect);
  if (S.settings.glass) { S.settings.glass = false; call('settings:set', { glass: false }); } document.body.classList.remove('glass');
  $('#brandIcon').src = `../assets/icons/${S.settings.icon}.png`;
  { const A = ({ night: ['#5d6b8a', '#8a97b5'], snow: ['#6b7a99', '#9aa6c0'], ocean: ['#1f8fae', '#2fbfa6'], wblack: ['#55606f', '#8893a3'], wwhite: ['#6b7a99', '#9aa6c0'], wdark: ['#2f7fd0', '#2fb7c9'], wgray: ['#5f6a7c', '#8e98a8'], wmint: ['#1fa77a', '#3ccf98'], wsunset: ['#d0613f', '#e99a5c'], neon: ['#1fa77a', '#3ccf98'], sunset: ['#d0613f', '#e99a5c'], graphite: ['#5f6a7c', '#8e98a8'] })[S.settings.icon] || ['#1f8fae', '#2fbfa6'];
    document.body.style.setProperty('--a1', A[0]); document.body.style.setProperty('--a2', A[1]); }
  document.body.style.setProperty('--iconc', ({ night: '#dfe3ec', snow: '#dfe3ec', ocean: '#22a9d0', wblack: '#e9ecf2', wwhite: '#e9ecf2', wdark: '#3b9cf0', wgray: '#b8bec9', wmint: '#3ddc97', wsunset: '#ff7a59', neon: '#3ddc97', sunset: '#ff8a5c', graphite: '#c9ced8' })[S.settings.icon] || '#22a9d0');
}
matchMedia('(prefers-color-scheme: light)').onchange = () => S && applyTheme();

const pingCls = p => p == null ? '' : p < 0 ? 'b' : p < 200 ? 'g' : p < 500 ? 'y' : 'b';
const pingTxt = p => p == null ? '—' : p < 0 ? 'N/A' : p + ' мс';
const dotCls = p => p == null ? '' : p > 0 ? 'ok' : 'bad';

function render() {
  applyTheme(); setStatus(S.status); $('#pinBtn').classList.toggle('on', !!S.settings.pinTop);
  $$('.modes button').forEach(b => b.classList.toggle('active', b.dataset.mode === S.mode));
  const all = S.subs.flatMap(s => s.nodes); const cur = all.find(n => n.tag === S.selected);
  $('#curNode').textContent = cur ? clean(cur.name) : 'Сервер не выбран';
  // серверы
  $('#servers').innerHTML = !S.subs.length ? `<div class="empty"><b>Подключите VPN Storm</b>Получите подписку в Telegram-боте и вставьте ссылку сюда<br><button class="btn1" data-bot>Подписка Storm в Telegram</button><br><button class="btn2" data-addsub>У меня уже есть ссылка</button></div>` : S.subs.map(s => `
   <div class="sgroup ${collapsed[s.id] ? 'collapsed' : ''}" data-id="${s.id}">
    <div class="sgroup-h"><i data-ic="chevd"></i><b>${esc(s.name)}</b><span>${s.nodes.length} серверов</span></div>
    <div class="nodes">${s.nodes.map(n => `<div class="node ${n.tag === S.selected ? 'sel' : ''} ${n.off ? 'off' : ''}" data-tag="${n.tag}">${avatar(n.name)}<div class="n"><div>${esc(clean(n.name))}</div></div><span class="dot ${dotCls(n.ping)}" id="d-${n.tag}" title="${n.ping == null ? 'Не проверялся' : n.ping > 0 ? 'Работает' : 'Не отвечает'}"></span>${n.off ? '<span class="ping">нужен Xray</span>' : `<span class="ping ${pingCls(n.ping)}" id="p-${n.tag}">${pingTxt(n.ping)}</span>`}</div>`).join('')}</div>
   </div>`).join('');
  // подписка на главной
  { const hs = $('#homeSub'); const sb = S.subs.find(x => x.nodes.some(n => n.tag === S.selected)) || S.subs[0];
    if (!sb) hs.classList.add('hidden'); else { const i = sb.info || {}; const left = i.expire ? Math.ceil((i.expire * 1000 - Date.now()) / 864e5) : null; const used = (i.upload || 0) + (i.download || 0); const okn = sb.nodes.filter(n => n.ping > 0).length;
      hs.classList.remove('hidden'); hs.innerHTML = `<i data-ic="layers"></i><b>${esc(sb.name)}</b><span>${left == null ? '∞' : Math.max(0, left) + ' дн'}</span><span>${okn}/${sb.nodes.length} серв.</span>${used ? `<span>${fmt(used)}</span>` : ''}`; } }
  // подписки
  $('#subCards').innerHTML = S.subs.map(s => {
    const i = s.info || {}; const used = (i.upload || 0) + (i.download || 0);
    const left = i.expire ? Math.ceil((i.expire * 1000 - Date.now()) / 864e5) : null;
    const best = s.nodes.filter(n => n.ping > 0).sort((x, y) => x.ping - y.ping)[0]; const ok = s.nodes.filter(n => n.ping > 0).length, bad = s.nodes.filter(n => n.ping != null && n.ping <= 0).length;
    const st = left != null && left <= 0 ? ['bad', 'Истекла'] : left != null && left <= 3 ? ['warn', 'Скоро закончится'] : ['ok', 'Активна'];
    const pct = left == null ? 100 : Math.max(0, Math.min(100, left / 30 * 100)); const C = 2 * Math.PI * 26;
    const ring = `<div class="ring ${st[0]}"><svg viewBox="0 0 60 60"><circle cx="30" cy="30" r="26" class="bg"/><circle cx="30" cy="30" r="26" class="fg" stroke-dasharray="${C}" stroke-dashoffset="${C * (1 - pct / 100)}"/></svg><div><b>${left == null ? '∞' : Math.max(0, left)}</b>${left == null ? '' : '<small>дн</small>'}</div></div>`;
    const flags = s.nodes.map(n => `<span class="mf ${n.ping > 0 ? 'ok' : n.ping != null ? 'bad' : ''}" title="${esc(clean(n.name))}">${avatar(n.name)}</span>`).join('');
    return `<div class="scard">
     <div class="scard-top">${ring}<div class="scard-t"><input value="${esc(s.name)}" data-rename="${s.id}" spellcheck="false"><span class="badge ${st[0]}"><i></i>${st[1]}</span></div><button class="scopy" data-copy="${s.id}" title="Скопировать ссылку"><i data-ic="paste"></i></button></div>
     <div class="sstats"><div><b class="g">${ok}<span>/${s.nodes.length}</span></b><small>работают</small></div><div><b>${best ? best.ping + '<span> мс</span>' : '—'}</b><small>${best ? esc(clean(best.name)) : 'лучший пинг'}</small></div><div><b>${used ? fmt(used) : '∞'}</b><small>${i.total ? 'из ' + fmt(i.total) : 'трафик'}</small></div><div><b>${i.expire ? new Date(i.expire * 1000).toLocaleDateString('ru', { day: 'numeric', month: 'short' }) : '∞'}</b><small>${i.expire ? 'действует до' : 'без срока'}</small></div></div>
     ${i.total ? `<div class="bar"><i style="width:${Math.min(100, used / i.total * 100)}%"></i></div>` : ''}
     <div class="mflags">${flags}</div>
     <div class="sfoot"><span><i data-ic="clock"></i>Обновлена ${ago(s.updated)}${bad ? ` · <em>${bad} не отвечают</em>` : ''}</span></div>
     <div class="sacts"><button data-ref="${s.id}"><i data-ic="refresh"></i>Обновить</button><button data-chk="${s.id}"><i data-ic="pulse"></i>Проверить</button><button class="del" data-del="${s.id}"><i data-ic="trash"></i></button></div>
    </div>`;
  }).join('') || `<div class="empty" style="margin-bottom:12px"><b>Пока пусто</b>Можно добавить несколько подписок сразу</div>`;
  requestAnimationFrame(fitFlags);
  // правила
  $('#rules').innerHTML = S.rules.map(r => `<div class="rule${r.preset === 'steam' ? ' steam' + (steamOpen ? ' open' : '') : ''}" data-id="${r.id}"><div class="grip" title="Перетащите"><i></i><i></i><i></i></div><div class="ic" ${ruleIcons[r.id] || r.kind === 'site' ? '' : 'data-ic="app"'}>${ruleIcons[r.id] ? `<img src="${ruleIcons[r.id]}">` : r.kind === 'site' ? (favC[r.value] ? `<img class="fav" src="${favC[r.value]}">` : (loadFav(r.value), `<i>${svg('globe')}</i>`)) : ''}</div><div class="n"><div>${esc(r.name || r.value)}</div><small>${r.kind === 'site' ? 'сайт и все его разделы' : r.preset === 'steam' ? (steamGames ? `игры: ${steamGames.length} · нажмите, чтобы ${steamOpen ? 'свернуть' : 'открыть'}` : 'нажмите — игры из библиотеки') : r.preset ? 'вместе с сайтами' : esc((r.process || []).length + ' файлов · ' + (r.folder || ''))}</small></div>
   <button class="pill route-t ${r.action === 'direct' ? 'dir' : 'vpn'}" data-rt="${r.id}">${r.action === 'direct' ? 'Напрямую' : 'VPN'}</button><button class="icb del" data-rd="${r.id}" data-ic="x"></button>${r.preset === 'steam' && steamOpen ? `<div class="games">${!steamGames ? '<div class="hint center">Ищу игры…</div>' : steamGames.map(g => `<div class="game"><div class="ic" ${g.icon ? '' : 'data-ic="app"'}>${g.icon ? `<img src="${g.icon}">` : ''}</div><div class="n"><div>${esc(g.name)}</div></div><button class="pill route-t ${g.action === 'direct' ? 'dir' : 'vpn'}" data-gt="${g.appid}" data-gr="${r.id}">${g.action === 'direct' ? 'Напрямую' : 'VPN'}</button></div>`).join('') || '<div class="hint center">В Steam нет установленных игр</div>'}</div>` : ''}</div>`).join('');
  if (S.rules.some(r => r.preset === 'steam')) loadSteam();
  loadRuleIcons();
  $('#globalNote').classList.toggle('hidden', S.mode !== 'global');
  const w = $('#vpnWarn'); w.classList.toggle('hidden', !S.otherVpn || S.status !== 'off'); w.textContent = S.otherVpn ? `Сейчас включён ${S.otherVpn}. Два VPN вместе не работают — выключите ${S.otherVpn}, потом подключайте Storm.` : '';
  const offN = S.subs.flatMap(s => s.nodes).filter(n => n.off).length; const xn = $('#xrayNote'); xn.classList.toggle('hidden', !offN); xn.textContent = offN ? `${offN} серв. работают только с ядром Xray — оно ещё не установлено.` : '';
  // настройки
  $$('[data-set]').forEach(i => i.checked = !!S.settings[i.dataset.set]);
  $$('[data-seg]').forEach(g => g.querySelectorAll('button').forEach(b => b.classList.toggle('active', S.settings[g.dataset.seg] === b.dataset.v)));
  $('#icons').innerHTML = ICONS.map(n => `<img src="../assets/icons/${n}.png" data-icon="${n}" class="${S.settings.icon === n ? 'active' : ''}">`).join('');
  $('#pingHint').textContent = S.settings.pingMode === 'full' ? 'С открытием нового соединения — как в других VPN-приложениях, цифра выше' : 'Задержка по уже открытому соединению — то, что вы реально чувствуете';
  $('#stackHint').textContent = ({ mixed: '1 — Смешанный: TCP через систему, UDP своим стеком. Быстро и стабильно, подходит почти всем', system: '2 — Системный: всё через сетевой стек Windows. Самый быстрый, но иногда конфликтует с антивирусом и играми', gvisor: '3 — gVisor: свой стек внутри приложения. Медленнее, зато работает там, где 1 и 2 не грузят' })[S.settings.stack] || '';
  $('#tDown').textContent = fmt(S.stats.totalDown); $('#tUp').textContent = fmt(S.stats.totalUp); $('#sSess').textContent = S.stats.sessions;
  paintIcons(); updateFab();
}

function setStatus(st) {
  S.status = st; document.body.classList.remove('on', 'connecting', 'off'); document.body.classList.add(st);
  $('#stText').textContent = st === 'on' ? 'Подключено' : st === 'connecting' ? 'Подключение…' : 'Не подключено';
  updateFab();
}

let steamGames = null, steamOpen = localStorage.steamOpen === '1', steamAt = 0;
async function loadSteam(force) { if (!force && Date.now() - steamAt < 15000) return; steamAt = Date.now(); const l = await call('steam:games'); if (JSON.stringify(l) !== JSON.stringify(steamGames)) { steamGames = l; render(); } }
let ruleIcons = {}, riKey = '';
async function loadRuleIcons() { const k = S.rules.map(r => r.id).join(','); if (k === riKey) return; riKey = k; const m = await call('rule:icons'); if (JSON.stringify(m) !== JSON.stringify(ruleIcons)) { ruleIcons = m; render(); } }
// значки сайтов: несколько источников по очереди, в конце — глобус
const favC = {}; const favReq = {};
function loadFav(d) { if (favReq[d]) return; favReq[d] = 1; call('favicon', d).then(u => { if (u) { favC[d] = u; render(); } }); }
const favSrc = (d, k) => [`https://icons.duckduckgo.com/ip3/${d}.ico`, `https://www.google.com/s2/favicons?domain=${d}&sz=64`, `https://${d}/favicon.ico`][k];
function favNext(img) { const k = +img.dataset.k + 1; if (k < 3) { img.dataset.k = k; img.src = favSrc(img.dataset.d, k); } else img.replaceWith(Object.assign(document.createElement('i'), { innerHTML: svg('globe') })); }
// ---------- главная ----------
$$('.modes button').forEach(b => b.onclick = () => { if (S.mode === b.dataset.mode) return; act(call('vpn:mode', b.dataset.mode)); toast(b.dataset.mode === 'global' ? 'Весь трафик идёт через VPN' : 'Работа по вашим правилам'); });
$('#servers').onclick = e => {
  const t = e.target; if (t.closest('[data-bot]')) return call('open', 'https://t.me/storm_fast_bot'); if (t.closest('[data-addsub]')) return openAdd();
  const node = t.closest('.node'); if (node) { if (node.classList.contains('off')) return toast('Этому серверу нужно ядро Xray — оно пока не установлено'); if (node.dataset.tag !== S.selected) act(call('vpn:select', node.dataset.tag)); return; }
  const h = t.closest('.sgroup-h'); if (h) { const id = h.parentElement.dataset.id; collapsed[id] = !collapsed[id]; localStorage.collapsed = JSON.stringify(collapsed); h.parentElement.classList.toggle('collapsed'); }
};
async function busy(btn, fn) { btn.classList.add('busy'); try { return await fn(); } finally { btn.classList.remove('busy'); } }
async function ping() { if (!S.subs.length) return openAdd(); $$('.ping').forEach(p => { p.textContent = '···'; p.className = 'ping'; }); $$('.dot').forEach(d => d.className = 'dot wait'); const r = await busy($('#pingBtn'), () => act(call('vpn:ping'))); if (r && r.warn) toast(r.warn); }
$('#pingBtn').onclick = ping;
if ($('#bestBtn')) $('#bestBtn').onclick = async () => { if (!S.subs.length) return openAdd(); if (!S.subs.some(s => s.nodes.some(n => n.ping > 0))) await ping(); const r = await act(call('vpn:best')); const n = r && r.subs.flatMap(s => s.nodes).find(x => x.tag === r.selected); if (n && n.ping > 0) toast('Самый быстрый: ' + clean(n.name) + ' · ' + n.ping + ' мс'); else toast('Нет доступных серверов'); };
async function refresh(id, btn) { const r = await busy(btn, () => act(call('sub:refresh', id))); if (r) toast(r.errors?.length ? r.errors[0] : 'Обновлено'); }
$('#refreshBtn').onclick = () => S.subs.length ? refresh(null, $('#refreshBtn')) : openAdd();

// ---------- подписки ----------
$('#subCards').onclick = async e => { const b = e.target.closest('button'); if (!b) return;
  if (b.dataset.del) { if (confirm('Удалить подписку и её серверы?')) act(call('sub:remove', b.dataset.del)); }
  else if (b.dataset.ref) refresh(b.dataset.ref, b);
  else if (b.dataset.copy) { const x = S.subs.find(q => q.id === b.dataset.copy); navigator.clipboard.writeText(x.url); toast('Ссылка подписки скопирована'); }
  else if (b.dataset.chk) { const x = S.subs.find(q => q.id === b.dataset.chk); const r = await busy(b, () => act(call('vpn:ping', x.nodes.map(n => n.tag)))); if (r) { const y = r.subs.find(q => q.id === x.id); toast(`Работают ${y.nodes.filter(n => n.ping > 0).length} из ${y.nodes.length}`); } } };
$('#subCards').addEventListener('change', e => { const id = e.target.dataset.rename; if (id && e.target.value.trim()) act(call('sub:rename', { id, name: e.target.value.trim() })); });
$('#subCards').addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.dataset.rename) e.target.blur(); });

function fill(r) { if (!r) return false; if (r.error) { toast(r.error); return false; } $('#subUrl').value = r.text; const n = $('#clipNote'); n.textContent = 'Ссылка вставлена из ' + r.from; n.classList.remove('hidden'); return true; }
async function openAdd() {
  $('#modal').classList.remove('hidden'); $('#subUrl').value = $('#subName').value = ''; $('#clipNote').classList.add('hidden');
  const r = await call('clip:read'); if (r && S.subs.some(s => s.url === r.text)) return $('#subUrl').focus();
  if (fill(r)) $('#subSave').focus(); else $('#subUrl').focus();
}
const closeAdd = () => $('#modal').classList.add('hidden');
$('#addSubBtn').onclick = $('#addSub2').onclick = openAdd;
$('#subCancel').onclick = closeAdd;
$('#modal').onclick = e => { if (e.target.id === 'modal') closeAdd(); };
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeAdd(); if (e.key === 'Enter' && !$('#modal').classList.contains('hidden') && e.target.id !== 'subUrl') $('#subSave').click(); });
$('#pasteBtn').onclick = async () => { if (!fill(await call('clip:read'))) toast('В буфере обмена нет ссылки'); };
$('#qrScreen').onclick = async () => { toast('Ищу QR-код на экране…'); const r = await call('qr:screen'); if (!fill(r)) toast('QR-код на экране не найден'); };
$('#qrFile').onclick = async () => fill(await call('qr:file'));
$('#subSave').onclick = async () => {
  const url = $('#subUrl').value.trim(); if (!url) return toast('Вставьте ссылку');
  const b = $('#subSave'); b.textContent = 'Загрузка…'; const r = await act(call('sub:add', { url, name: $('#subName').value.trim() })); b.textContent = 'Добавить';
  if (r) { closeAdd(); const s = r.subs[r.subs.length - 1]; toast(`«${s.name}»: ${s.nodes.length} серверов`); go('home'); ping(); }
};

// ---------- маршруты ----------
async function addSite(action) {
  const v = $('#siteInput').value.trim(); if (!v) { $('#siteInput').focus(); return toast('Введите адрес сайта'); }
  const key = Object.keys(presets).find(k => k === v.toLowerCase() || presets[k].toLowerCase() === v.toLowerCase());
  if (key) { if (S.rules.some(r => r.preset === key)) return toast('Уже добавлено'); await act(call('rule:add', { kind: 'app', preset: key, name: presets[key], action })); }
  else { const host = v.replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/^www\./, '').toLowerCase(); if (!host.includes('.')) return toast('Похоже, это не адрес сайта'); if (S.rules.some(r => r.value === host)) return toast('Уже добавлено'); await act(call('rule:add', { kind: 'site', value: host, name: host, action })); }
  $('#siteInput').value = '';
}
$('#addRoute').onclick = () => { const b = $('#addRoute'); const v = b.dataset.v === 'proxy' ? 'direct' : 'proxy'; b.dataset.v = v; b.className = 'pill route-t ' + (v === 'direct' ? 'dir' : 'vpn'); b.textContent = v === 'direct' ? 'Напрямую' : 'VPN'; };
$('#addSite').onclick = () => addSite($('#addRoute').dataset.v);
$('#siteInput').onkeydown = e => e.key === 'Enter' && addSite($('#addRoute').dataset.v);
$('#sitePaste').onclick = async () => { try { const t = (await navigator.clipboard.readText()).trim(); if (!t) return toast('Буфер обмена пуст'); $('#siteInput').value = t.split(/\s+/)[0]; $('#siteInput').focus(); } catch { toast('Не удалось прочитать буфер'); } };
async function addExe(r) { if (!r) return; if (r.preset && S.rules.some(x => x.preset === r.preset)) return toast(r.name + ' уже в списке'); await act(call('rule:add', { kind: 'app', name: r.name, preset: r.preset, folder: r.folder, process: r.process, exePath: r.exePath, action: 'proxy' })); if (r.preset === 'steam') { steamOpen = true; localStorage.steamOpen = '1'; steamAt = 0; render(); } riKey = ''; toast(r.preset ? r.name + ': программа и её сайты' : `${r.name}: добавлено файлов — ${r.process.length}`); }
let appsList = null;
function drawApps() { const q = $('#appSearch').value.trim().toLowerCase(); const l = (appsList || []).filter(a => !/sechealth|storepurchase|yourphone/i.test(a.name)).filter(a => !q || a.name.toLowerCase().includes(q)).sort((a, b) => q ? (b.name.toLowerCase().startsWith(q) - a.name.toLowerCase().startsWith(q)) || (b.name.toLowerCase().split(/\s+/).some(w => w.startsWith(q)) - a.name.toLowerCase().split(/\s+/).some(w => w.startsWith(q))) : 0);
  $('#appList').innerHTML = !appsList ? '<div class="hint center">Ищу программы…</div>' : l.map(a => `<div class="appi" data-exe="${esc(a.exe)}">${a.icon ? `<img src="${a.icon}">` : '<i data-ic="app"></i>'}<div class="n"><div>${esc(a.name)}</div><small>${esc(a.exe.split('\\').pop())}</small></div></div>`).join('') || '<div class="hint center">Ничего не найдено</div>'; paintIcons($('#appList')); }
$('#pickExe').onclick = async () => { $('#appsModal').classList.remove('hidden'); $('#appSearch').value = ''; drawApps(); $('#appSearch').focus(); appsList = await call('apps:list'); drawApps(); };
window.vpn.on('apps', l => { appsList = l; riKey = ''; S && loadRuleIcons(); if (!$('#appsModal').classList.contains('hidden')) drawApps(); });
$('#appSearch').oninput = drawApps;
$('#appList').onclick = async e => { const it = e.target.closest('.appi'); if (!it) return; $('#appsModal').classList.add('hidden'); addExe(await call('rule:fromExe', it.dataset.exe)); };
$('#appBrowse').onclick = async () => { $('#appsModal').classList.add('hidden'); addExe(await call('rule:pickExe')); };
$('#appsModal').onclick = e => { if (e.target.id === 'appsModal' || e.target.id === 'appClose') $('#appsModal').classList.add('hidden'); };
$('#rules').onclick = e => { const t = e.target.closest('button');
  if (!t) { if (e.target.closest('.rule.steam') && !e.target.closest('.games,.grip')) { steamOpen = !steamOpen; localStorage.steamOpen = steamOpen ? '1' : '0'; render(); if (steamOpen) loadSteam(true); } return; }
  if (t.dataset.gt) { const g = steamGames.find(x => x.appid === t.dataset.gt); const v = g.action === 'direct' ? 'proxy' : 'direct'; g.action = v; t.className = 'pill route-t ' + (v === 'direct' ? 'dir' : 'vpn'); t.textContent = v === 'direct' ? 'Напрямую' : 'VPN'; call('rule:game', { id: t.dataset.gr, appid: g.appid, action: v }).then(r => { S = r; }).catch(() => { }); return; }
  if (t.dataset.rt) { const r = S.rules.find(x => x.id === t.dataset.rt); const v = r.action === 'direct' ? 'proxy' : 'direct'; r.action = v; t.className = 'pill route-t ' + (v === 'direct' ? 'dir' : 'vpn'); t.textContent = v === 'direct' ? 'Напрямую' : 'VPN'; call('rule:update', { id: r.id, action: v }).catch(() => { }); }
  if (t.dataset.rd) act(call('rule:remove', t.dataset.rd)); };
// перетаскивание правил за «ручку»
$('#rules').addEventListener('pointerdown', e => {
  const g = e.target.closest('.grip'); if (!g) return; e.preventDefault();
  const row = g.closest('.rule'), box = $('#rules'); const r0 = row.getBoundingClientRect(); const dy0 = e.clientY - r0.top;
  const ph = document.createElement('div'); ph.className = 'rule-ph'; ph.style.height = r0.height + 'px'; row.after(ph);
  Object.assign(row.style, { position: 'fixed', left: r0.left + 'px', top: r0.top + 'px', width: r0.width + 'px', zIndex: 50 }); row.classList.add('drag');
  const move = ev => { row.style.top = (ev.clientY - dy0) + 'px'; const sib = [...box.querySelectorAll('.rule:not(.drag)')]; const after = sib.find(x => { const b = x.getBoundingClientRect(); return ev.clientY < b.top + b.height / 2; }); after ? box.insertBefore(ph, after) : box.appendChild(ph); };
  const up = () => { removeEventListener('pointermove', move); removeEventListener('pointerup', up); ph.replaceWith(row); row.removeAttribute('style'); row.classList.remove('drag'); const ids = [...box.querySelectorAll('.rule')].map(x => x.dataset.id); call('rule:reorder', ids).then(r => { S = r; }); };
  addEventListener('pointermove', move); addEventListener('pointerup', up);
});

// ---------- настройки ----------
$$('[data-set]').forEach(i => i.onchange = () => act(call('settings:set', { [i.dataset.set]: i.checked })));
$$('[data-seg]').forEach(g => g.onclick = e => { const v = e.target.dataset.v; if (v) act(call('settings:set', { [g.dataset.seg]: v })); });
$('#icons').onclick = e => { const n = e.target.dataset.icon; if (n) act(call('settings:set', { icon: n })); };
$('#resetStats').onclick = () => confirm('Сбросить статистику?') && act(call('stats:reset'));

// ---------- журнал ----------
const logLine = l => { const c = /ERROR|FATAL/.test(l) ? 'e' : /WARN/.test(l) ? 'w' : ''; return `<div class="${c}">${esc(l)}</div>`; };
async function loadLogs() { const l = await call('logs'); $('#logBox').innerHTML = l.map(logLine).join('') || 'Пока пусто — журнал появится после подключения.'; const p = $('#p-logs'); p.scrollTop = p.scrollHeight; }
$('#clearLogs').onclick = () => { call('logs:clear'); $('#logBox').innerHTML = ''; };
$('#copyLogs').onclick = () => { navigator.clipboard.writeText($('#logBox').innerText); toast('Скопировано'); };

// ---------- живые события ----------
window.vpn.on('status', st => setStatus(st));
window.vpn.on('state', s => { S = s; render(); });
window.vpn.on('ping', ({ tag, ms }) => { const el = document.getElementById('p-' + tag); if (el) { el.textContent = pingTxt(ms); el.className = 'ping ' + pingCls(ms); } const d = document.getElementById('d-' + tag); if (d) { d.className = 'dot ' + dotCls(ms); d.title = ms > 0 ? 'Работает' : 'Не отвечает'; } });
window.vpn.on('log', l => { if (page !== 'logs') return; const box = $('#logBox'); box.insertAdjacentHTML('beforeend', logLine(l)); if (box.children.length > 800) box.firstChild.remove(); const p = $('#p-logs'); p.scrollTop = p.scrollHeight; });
window.vpn.on('conns', n => $('#sConns').textContent = n);
window.vpn.on('traffic', t => {
  $('#spDown').textContent = fmt(t.down) + '/с'; $('#spUp').textContent = fmt(t.up) + '/с';
  if (t.session) { $('#sDown').textContent = fmt(t.session.down); $('#sUp').textContent = fmt(t.session.up); if (S.status === 'on' && t.session.start) { const s = Math.floor((Date.now() - t.session.start) / 1000); $('#stTime').textContent = [s / 3600 | 0, (s / 60 | 0) % 60, s % 60].map(x => String(x).padStart(2, '0')).join(':'); } }
  hist.push([t.down, t.up]); if (hist.length > 60) hist.shift(); if (page === 'stats') drawChart(); if (page === 'home') drawSpark();
});
function drawChart() {
  const c = $('#chart'); if (!c.offsetWidth) return; const w = c.width = c.offsetWidth * 2, h = c.height = 220, x = c.getContext('2d');
  const max = Math.max(1024, ...hist.flat()); const cs = getComputedStyle(document.body);
  [[0, cs.getPropertyValue('--ok')], [1, cs.getPropertyValue('--acc')]].forEach(([k, col]) => {
    x.beginPath(); hist.forEach((v, i) => { const px = i / 59 * w, py = h - 8 - v[k] / max * (h - 40); i ? x.lineTo(px, py) : x.moveTo(px, py); }); x.strokeStyle = col; x.lineWidth = 4; x.lineJoin = 'round'; x.stroke();
  });
  x.fillStyle = cs.getPropertyValue('--mut'); x.font = '20px Segoe UI'; x.fillText('пик ' + fmt(max) + '/с', 4, 22);
}

(async () => { paintIcons(); presets = await call('presets'); S = await call('state'); render(); })();
setInterval(async () => { if (!S) return; const n = await call('state'); if (n.otherVpn !== S.otherVpn || n.hasXray !== S.hasXray) { S.otherVpn = n.otherVpn; S.hasXray = n.hasXray; S.subs = n.subs; render(); } }, 2000);
window.vpn.on('notice', t => toast(t));

// флажки серверов в одну строку: если не влезают — аккуратно заходят друг на друга
const flagRO = new ResizeObserver(() => fitFlags()); function fitFlags() { $$('.mflags').forEach(b => { if (!b._ro) { b._ro = 1; flagRO.observe(b); } }); $$('.mflags').forEach(box => { const it = [...box.children]; if (!it.length) return; it.forEach(x => { x.style.marginLeft = ''; x.style.zIndex = ''; }); const w = it[0].offsetWidth, gap = 4, n = it.length, need = n * w + (n - 1) * gap, room = box.clientWidth - 10; if (need <= room || n < 2) return; const step = Math.max(8, (room - w) / (n - 1)); it.forEach((x, i) => { if (i) x.style.marginLeft = (step - w - gap) + 'px'; x.style.zIndex = n - i; }); }); }
addEventListener('resize', fitFlags);

// ---------- Запрет ----------
let Z = null;
const zName = n => { const m = n.match(/ALT(\d*)/i); return m ? 'ALT ' + (m[1] || 1) : n; };
function drawZ(z, testing) {
  if (!z) return; Z = z; const on = !!(z.on && z.running);
  $('#zCard').classList.toggle('on', on); $('#zOn').checked = !!z.on;
  $('#zSt').textContent = z.busy ? 'Подбираю…' : on ? 'Работает' : z.on ? 'Запускаю…' : 'Выключен';
  $('#zStrat').textContent = (z.strat ? 'Способ: ' + zName(z.strat) : 'Способ не выбран') + (z.auto ? ' · автовыбор' : '');
  $('#zAuto').classList.toggle('on', !!z.auto);
  const t = z.test || {}; const st = (d, m, v) => { $(d).className = 'dot ' + (v == null ? '' : v > 0 ? 'ok' : 'bad'); $(m).textContent = v == null ? '—' : v > 0 ? v + ' мс' : 'не грузится'; };
  st('#zdD', '#zmD', t.discord); st('#zdY', '#zmY', t.youtube);
  if (testing) $('#zStrat').textContent = 'Пробую ' + zName(testing) + '…';
  $('#zList').innerHTML = (z.list || []).map(n => `<button class="zalt ${n === z.strat ? 'sel' : ''} ${n === testing ? 'testing' : ''}" data-z="${esc(n)}">${esc(zName(n))}</button>`).join('') || '<div class="empty"><b>Папка запрета не найдена</b>' + esc(z.dir || '') + '</div>';
  $('#zDir').textContent = z.dir ? 'Папка: ' + z.dir : '';
  paintIcons($('#p-zapret'));
}
window.vpn.on('zapret', z => drawZ(z, z.testing));
$('#zOn').onchange = async e => { const r = await act(call(e.target.checked ? 'z:start' : 'z:stop')); if (r) { drawZ(r); if (r.on) { toast('Запрет включён'); drawZ(await call('z:test'))} else toast('Запрет выключен'); } };
$('#zTest').onclick = async () => { const b = $('#zTest'); const r = await busy(b, () => call('z:test')); drawZ(r); const t = r.test; toast(t.discord > 0 && t.youtube > 0 ? 'Discord и YouTube работают' : 'Что-то не грузится — попробуйте другой способ'); };
$('#zAuto').onclick = async () => { const v = !(Z && Z.auto); const r = await busy($('#zAuto'), () => call('z:autoMode', v)); drawZ(r); toast(v ? 'Автовыбор: проверяю каждые 20 с и сам переключаю ALT' : 'Автовыбор выключен'); };
setInterval(async () => { if (page === 'zapret' && Z && Z.on && !Z.busy) drawZ(await call('z:test')); }, 30000);
$('#zList').onclick = async e => { const b = e.target.closest('[data-z]'); if (!b) return; const r = await act(call('z:start', b.dataset.z)); if (r) { drawZ(r); toast('Способ: ' + zName(b.dataset.z)); drawZ(await call('z:test')); } };

// ---------- график скорости на главной ----------
function drawSpark() {
  const c = $('#spark'); if (!c || !c.offsetWidth) return; const w = c.width = c.offsetWidth * 2, h = c.height = 64, x = c.getContext('2d');
  const on = S && S.status === 'on'; c.classList.toggle('show', on && hist.length > 2); if (!on) return;
  const max = Math.max(4096, ...hist.map(v => v[0] + v[1])); const cs = getComputedStyle(document.body); const col = cs.getPropertyValue('--ok').trim() || '#3ddc97';
  const pts = hist.map((v, i) => [i / 59 * w, h - 4 - (v[0] + v[1]) / max * (h - 10)]);
  const g = x.createLinearGradient(0, 0, 0, h); g.addColorStop(0, col + '55'); g.addColorStop(1, col + '00');
  x.beginPath(); pts.forEach(([px, py], i) => i ? x.lineTo(px, py) : x.moveTo(px, py)); x.lineTo(pts[pts.length - 1][0], h); x.lineTo(0, h); x.closePath(); x.fillStyle = g; x.fill();
  x.beginPath(); pts.forEach(([px, py], i) => i ? x.lineTo(px, py) : x.moveTo(px, py)); x.strokeStyle = col; x.lineWidth = 3; x.lineJoin = 'round'; x.stroke();
}
// ---------- «Мой IP»: сам проверяется при запуске, подключении и смене сервера; флаг страны вместо планеты ----------
let ipKey = '', ipBusy = false;
async function checkIp(manual) {
  if (ipBusy) return; ipBusy = true; const b = $('#ipBtn'); b.classList.add('busy');
  const r = await call('myip').catch(() => null); b.classList.remove('busy'); ipBusy = false;
  if (!r || !r.vpn) { $('#ipTxt').textContent = 'IP не определился'; $('#ipSub').textContent = ''; return; }
  const v = r.vpn;
  // выходы Storm: базы геолокации путают страну (адреса зарегистрированы на зарубежные компании)
  const KNOWN = { '48.102.178.238': ['de', 'Германия', 'Франкфурт'], '217.144.190.131': ['de', 'Германия', 'Франкфурт'], '31.76.49.218': ['nl', 'Нидерланды', 'Амстердам'] };
  if (KNOWN[v.ip]) { [v.cc, v.country, v.city] = KNOWN[v.ip]; }
  $('#ipIc').innerHTML = v.cc ? `<img src="../node_modules/flag-icons/flags/1x1/${v.cc}.svg">` : svg('globe');
  $('#ipTxt').textContent = v.country || v.ip; $('#ipSub').textContent = v.ip + (v.city ? ' · ' + v.city : '');
  b.classList.toggle('leak', r.leak); b.classList.toggle('safe', !r.leak && S.status === 'on');
  if (manual) toast(r.leak ? '⚠ Утечка: сайты видят твой настоящий IP' : S.status === 'on' ? 'VPN работает — сайты видят ' + (v.country || v.ip) : 'Без VPN: ' + (v.country || v.ip));
}
setInterval(() => { if (!S || S.status === 'connecting') return; const k = S.status + '|' + S.selected; if (k !== ipKey) { ipKey = k; setTimeout(() => checkIp(false), 1200); } }, 1000);
setInterval(() => S && S.status === 'on' && checkIp(false), 60000);
$('#ipBtn').onclick = () => checkIp(true);

